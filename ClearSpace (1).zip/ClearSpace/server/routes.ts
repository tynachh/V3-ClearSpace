import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodEntrySchema, insertJournalEntrySchema, insertBalanceEntrySchema, insertTaskSchema, insertWellnessSchema, insertThoughtBubbleSchema, insertScheduleEventSchema, insertFavoriteQuoteSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock user ID for demo (in real app, this would come from authentication)
  const DEMO_USER_ID = 1;

  // Mood entries
  app.get("/api/mood-entries", async (req, res) => {
    try {
      const entries = await storage.getMoodEntries(DEMO_USER_ID);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.post("/api/mood-entries", async (req, res) => {
    try {
      const validatedData = insertMoodEntrySchema.parse(req.body);
      const entry = await storage.createMoodEntry(DEMO_USER_ID, validatedData);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid mood entry data" });
    }
  });

  // Journal entries
  app.get("/api/journal-entries", async (req, res) => {
    try {
      const entries = await storage.getJournalEntries(DEMO_USER_ID);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch journal entries" });
    }
  });

  app.post("/api/journal-entries", async (req, res) => {
    try {
      const validatedData = insertJournalEntrySchema.parse(req.body);
      const entry = await storage.createJournalEntry(DEMO_USER_ID, validatedData);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid journal entry data" });
    }
  });

  app.delete("/api/journal-entries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteJournalEntry(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete journal entry" });
    }
  });

  // Balance entries
  app.get("/api/balance-entries", async (req, res) => {
    try {
      const entries = await storage.getBalanceEntries(DEMO_USER_ID);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch balance entries" });
    }
  });

  app.post("/api/balance-entries", async (req, res) => {
    try {
      const validatedData = insertBalanceEntrySchema.parse(req.body);
      const entry = await storage.createBalanceEntry(DEMO_USER_ID, validatedData);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid balance entry data" });
    }
  });

  // Tasks
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks(DEMO_USER_ID);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const validatedData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(DEMO_USER_ID, validatedData);
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const task = await storage.updateTask(id, updates);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Invalid task update data" });
    }
  });

  // Wellness
  app.get("/api/wellness", async (req, res) => {
    try {
      const entries = await storage.getWellnessEntries(DEMO_USER_ID);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch wellness entries" });
    }
  });

  app.get("/api/wellness/today", async (req, res) => {
    try {
      const todaysEntry = await storage.getTodaysWellness(DEMO_USER_ID);
      res.json(todaysEntry || { 
        water: 0, 
        exercise: 0, 
        sleep: 0, 
        waterGoal: 8, 
        exerciseGoal: 30,
        bedtime: "10:00 PM",
        wakeTime: "7:00 AM"
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's wellness" });
    }
  });

  app.post("/api/wellness", async (req, res) => {
    try {
      const validatedData = insertWellnessSchema.parse(req.body);
      const entry = await storage.createWellnessEntry(DEMO_USER_ID, validatedData);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid wellness data" });
    }
  });

  app.patch("/api/wellness", async (req, res) => {
    try {
      const { date, ...updates } = req.body;
      const entry = await storage.updateWellness(DEMO_USER_ID, date || new Date().toISOString().split('T')[0], updates);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid wellness update data" });
    }
  });

  // Tasks - Add delete route
  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTask(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete task" });
    }
  });

  // Thought Bubbles
  app.get("/api/thought-bubbles", async (req, res) => {
    try {
      const bubbles = await storage.getThoughtBubbles(DEMO_USER_ID);
      res.json(bubbles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch thought bubbles" });
    }
  });

  app.post("/api/thought-bubbles", async (req, res) => {
    try {
      const validatedData = insertThoughtBubbleSchema.parse(req.body);
      const bubble = await storage.createThoughtBubble(DEMO_USER_ID, validatedData);
      res.json(bubble);
    } catch (error) {
      res.status(400).json({ message: "Invalid thought bubble data" });
    }
  });

  app.patch("/api/thought-bubbles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const bubble = await storage.updateThoughtBubble(id, updates);
      res.json(bubble);
    } catch (error) {
      res.status(400).json({ message: "Failed to update thought bubble" });
    }
  });

  app.delete("/api/thought-bubbles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteThoughtBubble(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete thought bubble" });
    }
  });

  // Schedule Events
  app.get("/api/schedule-events", async (req, res) => {
    try {
      const date = req.query.date as string || new Date().toISOString().split('T')[0];
      const events = await storage.getScheduleEvents(DEMO_USER_ID, date);
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch schedule events" });
    }
  });

  app.post("/api/schedule-events", async (req, res) => {
    try {
      const validatedData = insertScheduleEventSchema.parse(req.body);
      const event = await storage.createScheduleEvent(DEMO_USER_ID, validatedData);
      res.json(event);
    } catch (error) {
      res.status(400).json({ message: "Invalid schedule event data" });
    }
  });

  app.patch("/api/schedule-events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const event = await storage.updateScheduleEvent(id, updates);
      res.json(event);
    } catch (error) {
      res.status(400).json({ message: "Failed to update schedule event" });
    }
  });

  app.delete("/api/schedule-events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteScheduleEvent(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete schedule event" });
    }
  });

  // Favorite Quotes
  app.get("/api/favorite-quotes", async (req, res) => {
    try {
      const quotes = await storage.getFavoriteQuotes(DEMO_USER_ID);
      res.json(quotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorite quotes" });
    }
  });

  app.post("/api/favorite-quotes", async (req, res) => {
    try {
      const validatedData = insertFavoriteQuoteSchema.parse(req.body);
      const quote = await storage.createFavoriteQuote(DEMO_USER_ID, validatedData);
      res.json(quote);
    } catch (error) {
      res.status(400).json({ message: "Invalid quote data" });
    }
  });

  app.delete("/api/favorite-quotes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteFavoriteQuote(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete quote" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
