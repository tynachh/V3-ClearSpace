import { 
  thoughtBubbles,
  scheduleEvents,
  favoriteQuotes,
  type User, 
  type InsertUser, 
  type MoodEntry, 
  type InsertMoodEntry,
  type JournalEntry, 
  type InsertJournalEntry, 
  type BalanceEntry, 
  type InsertBalanceEntry,
  type Task, 
  type InsertTask, 
  type Wellness, 
  type InsertWellness,
  type ThoughtBubble,
  type InsertThoughtBubble,
  type ScheduleEvent,
  type InsertScheduleEvent,
  type FavoriteQuote,
  type InsertFavoriteQuote
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import * as schema from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mood entries
  createMoodEntry(userId: number, entry: InsertMoodEntry): Promise<MoodEntry>;
  getMoodEntries(userId: number): Promise<MoodEntry[]>;
  
  // Journal entries
  createJournalEntry(userId: number, entry: InsertJournalEntry): Promise<JournalEntry>;
  getJournalEntries(userId: number): Promise<JournalEntry[]>;
  deleteJournalEntry(id: number): Promise<void>;
  
  // Balance entries
  createBalanceEntry(userId: number, entry: InsertBalanceEntry): Promise<BalanceEntry>;
  getBalanceEntries(userId: number): Promise<BalanceEntry[]>;
  
  // Tasks
  createTask(userId: number, task: InsertTask): Promise<Task>;
  getTasks(userId: number): Promise<Task[]>;
  updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<void>;
  
  // Wellness
  createWellnessEntry(userId: number, wellness: InsertWellness): Promise<Wellness>;
  getWellnessEntries(userId: number): Promise<Wellness[]>;
  getTodaysWellness(userId: number): Promise<Wellness | undefined>;
  updateWellness(userId: number, date: string, updates: Partial<InsertWellness>): Promise<Wellness>;

  // Thought Bubbles
  getThoughtBubbles(userId: number): Promise<ThoughtBubble[]>;
  createThoughtBubble(userId: number, bubble: InsertThoughtBubble): Promise<ThoughtBubble>;
  updateThoughtBubble(id: number, updates: Partial<ThoughtBubble>): Promise<ThoughtBubble>;
  deleteThoughtBubble(id: number): Promise<void>;

  // Schedule Events
  getScheduleEvents(userId: number, date: string): Promise<ScheduleEvent[]>;
  createScheduleEvent(userId: number, event: InsertScheduleEvent): Promise<ScheduleEvent>;
  updateScheduleEvent(id: number, updates: Partial<ScheduleEvent>): Promise<ScheduleEvent>;
  deleteScheduleEvent(id: number): Promise<void>;

  // Favorite Quotes
  getFavoriteQuotes(userId: number): Promise<FavoriteQuote[]>;
  createFavoriteQuote(userId: number, quote: InsertFavoriteQuote): Promise<FavoriteQuote>;
  deleteFavoriteQuote(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(schema.users).values(user).returning();
    return newUser;
  }

  async createMoodEntry(userId: number, entry: InsertMoodEntry): Promise<MoodEntry> {
    const [newEntry] = await db.insert(schema.moodEntries).values({ ...entry, userId }).returning();
    return newEntry;
  }

  async getMoodEntries(userId: number): Promise<MoodEntry[]> {
    return await db.select().from(schema.moodEntries).where(eq(schema.moodEntries.userId, userId));
  }

  async createJournalEntry(userId: number, entry: InsertJournalEntry): Promise<JournalEntry> {
    const [newEntry] = await db.insert(schema.journalEntries).values({ ...entry, userId }).returning();
    return newEntry;
  }

  async deleteJournalEntry(id: number): Promise<void> {
    await db.delete(schema.journalEntries).where(eq(schema.journalEntries.id, id));
  }

  async getJournalEntries(userId: number): Promise<JournalEntry[]> {
    return await db.select().from(schema.journalEntries).where(eq(schema.journalEntries.userId, userId));
  }

  async createBalanceEntry(userId: number, entry: InsertBalanceEntry): Promise<BalanceEntry> {
    const [newEntry] = await db.insert(schema.balanceEntries).values({ ...entry, userId }).returning();
    return newEntry;
  }

  async getBalanceEntries(userId: number): Promise<BalanceEntry[]> {
    return await db.select().from(schema.balanceEntries).where(eq(schema.balanceEntries.userId, userId));
  }

  async createTask(userId: number, task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(schema.tasks).values({ ...task, userId }).returning();
    return newTask;
  }

  async getTasks(userId: number): Promise<Task[]> {
    return await db.select().from(schema.tasks).where(eq(schema.tasks.userId, userId));
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    const [updatedTask] = await db.update(schema.tasks)
      .set(updates)
      .where(eq(schema.tasks.id, id))
      .returning();
    return updatedTask;
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(schema.tasks).where(eq(schema.tasks.id, id));
  }

  async createWellnessEntry(userId: number, wellness: InsertWellness): Promise<Wellness> {
    const [newEntry] = await db.insert(schema.wellness).values({ ...wellness, userId }).returning();
    return newEntry;
  }

  async getWellnessEntries(userId: number): Promise<Wellness[]> {
    return await db.select().from(schema.wellness).where(eq(schema.wellness.userId, userId));
  }

  async getTodaysWellness(userId: number): Promise<Wellness | undefined> {
    const today = new Date().toISOString().split('T')[0];
    const [wellness] = await db.select().from(schema.wellness)
      .where(and(eq(schema.wellness.userId, userId), eq(schema.wellness.date, today)))
      .orderBy(schema.wellness.id);
    return wellness || undefined;
  }

  async updateWellness(userId: number, date: string, updates: Partial<InsertWellness>): Promise<Wellness> {
    const existing = await db.select().from(schema.wellness)
      .where(and(eq(schema.wellness.userId, userId), eq(schema.wellness.date, date)));
    
    if (existing.length > 0) {
      const [updated] = await db.update(schema.wellness)
        .set(updates)
        .where(and(eq(schema.wellness.userId, userId), eq(schema.wellness.date, date)))
        .returning();
      return updated;
    } else {
      const [newEntry] = await db.insert(schema.wellness)
        .values({ ...updates, userId, date })
        .returning();
      return newEntry;
    }
  }

  async getThoughtBubbles(userId: number): Promise<ThoughtBubble[]> {
    return await db.select().from(schema.thoughtBubbles).where(eq(schema.thoughtBubbles.userId, userId));
  }

  async createThoughtBubble(userId: number, bubble: InsertThoughtBubble): Promise<ThoughtBubble> {
    const [newBubble] = await db.insert(schema.thoughtBubbles).values({ ...bubble, userId }).returning();
    return newBubble;
  }

  async updateThoughtBubble(id: number, updates: Partial<ThoughtBubble>): Promise<ThoughtBubble> {
    const [updated] = await db.update(schema.thoughtBubbles)
      .set(updates)
      .where(eq(schema.thoughtBubbles.id, id))
      .returning();
    return updated;
  }

  async deleteThoughtBubble(id: number): Promise<void> {
    await db.delete(schema.thoughtBubbles).where(eq(schema.thoughtBubbles.id, id));
  }

  async getScheduleEvents(userId: number, date: string): Promise<ScheduleEvent[]> {
    return await db.select().from(schema.scheduleEvents)
      .where(and(eq(schema.scheduleEvents.userId, userId), eq(schema.scheduleEvents.date, date)));
  }

  async createScheduleEvent(userId: number, event: InsertScheduleEvent): Promise<ScheduleEvent> {
    const [newEvent] = await db.insert(schema.scheduleEvents).values({ ...event, userId }).returning();
    return newEvent;
  }

  async updateScheduleEvent(id: number, updates: Partial<ScheduleEvent>): Promise<ScheduleEvent> {
    const [updated] = await db.update(schema.scheduleEvents)
      .set(updates)
      .where(eq(schema.scheduleEvents.id, id))
      .returning();
    return updated;
  }

  async deleteScheduleEvent(id: number): Promise<void> {
    await db.delete(schema.scheduleEvents).where(eq(schema.scheduleEvents.id, id));
  }

  async getFavoriteQuotes(userId: number): Promise<FavoriteQuote[]> {
    return await db.select().from(schema.favoriteQuotes)
      .where(eq(schema.favoriteQuotes.userId, userId));
  }

  async createFavoriteQuote(userId: number, quote: InsertFavoriteQuote): Promise<FavoriteQuote> {
    const [newQuote] = await db.insert(schema.favoriteQuotes).values({ ...quote, userId }).returning();
    return newQuote;
  }

  async deleteFavoriteQuote(id: number): Promise<void> {
    await db.delete(schema.favoriteQuotes).where(eq(schema.favoriteQuotes.id, id));
  }
}

// In-memory storage implementation
class MemoryStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private moodEntries: MoodEntry[] = [];
  private journalEntries: JournalEntry[] = [];
  private balanceEntries: BalanceEntry[] = [];
  private tasks: Task[] = [];
  private wellness: Wellness[] = [];
  private thoughtBubbles: ThoughtBubble[] = [];
  private scheduleEvents: ScheduleEvent[] = [];
  private favoriteQuotes: FavoriteQuote[] = [];
  private nextId = 1;

  constructor() {
    // Initialize demo user
    this.users.set(1, { id: 1, username: "demo_user", email: "demo@example.com" });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) return user;
    }
    return undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const newUser: User = { ...user, id: this.nextId++ };
    this.users.set(newUser.id, newUser);
    return newUser;
  }

  async createMoodEntry(userId: number, entry: InsertMoodEntry): Promise<MoodEntry> {
    const newEntry: MoodEntry = { ...entry, id: this.nextId++, userId };
    this.moodEntries.push(newEntry);
    return newEntry;
  }

  async getMoodEntries(userId: number): Promise<MoodEntry[]> {
    return this.moodEntries.filter(entry => entry.userId === userId);
  }

  async createJournalEntry(userId: number, entry: InsertJournalEntry): Promise<JournalEntry> {
    const newEntry: JournalEntry = { ...entry, id: this.nextId++, userId };
    this.journalEntries.push(newEntry);
    return newEntry;
  }

  async getJournalEntries(userId: number): Promise<JournalEntry[]> {
    return this.journalEntries.filter(entry => entry.userId === userId);
  }

  async deleteJournalEntry(id: number): Promise<void> {
    const index = this.journalEntries.findIndex(entry => entry.id === id);
    if (index !== -1) {
      this.journalEntries.splice(index, 1);
    }
  }

  async createBalanceEntry(userId: number, entry: InsertBalanceEntry): Promise<BalanceEntry> {
    const newEntry: BalanceEntry = { ...entry, id: this.nextId++, userId };
    this.balanceEntries.push(newEntry);
    return newEntry;
  }

  async getBalanceEntries(userId: number): Promise<BalanceEntry[]> {
    return this.balanceEntries.filter(entry => entry.userId === userId);
  }

  async createTask(userId: number, task: InsertTask): Promise<Task> {
    const newTask: Task = { ...task, id: this.nextId++, userId };
    this.tasks.push(newTask);
    return newTask;
  }

  async getTasks(userId: number): Promise<Task[]> {
    return this.tasks.filter(task => task.userId === userId);
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.find(task => task.id === id);
    if (task) {
      Object.assign(task, updates);
      return task;
    }
    return undefined;
  }

  async deleteTask(id: number): Promise<void> {
    const index = this.tasks.findIndex(task => task.id === id);
    if (index !== -1) {
      this.tasks.splice(index, 1);
    }
  }

  async createWellnessEntry(userId: number, wellness: InsertWellness): Promise<Wellness> {
    const newEntry: Wellness = { ...wellness, id: this.nextId++, userId };
    this.wellness.push(newEntry);
    return newEntry;
  }

  async getWellnessEntries(userId: number): Promise<Wellness[]> {
    return this.wellness.filter(entry => entry.userId === userId);
  }

  async getTodaysWellness(userId: number): Promise<Wellness | undefined> {
    const today = new Date().toISOString().split('T')[0];
    return this.wellness.find(entry => entry.userId === userId && entry.date === today);
  }

  async updateWellness(userId: number, date: string, updates: Partial<InsertWellness>): Promise<Wellness> {
    const existing = this.wellness.find(entry => entry.userId === userId && entry.date === date);
    
    if (existing) {
      Object.assign(existing, updates);
      return existing;
    } else {
      const newEntry: Wellness = { ...updates, id: this.nextId++, userId, date } as Wellness;
      this.wellness.push(newEntry);
      return newEntry;
    }
  }

  async getThoughtBubbles(userId: number): Promise<ThoughtBubble[]> {
    return this.thoughtBubbles.filter(bubble => bubble.userId === userId);
  }

  async createThoughtBubble(userId: number, bubble: InsertThoughtBubble): Promise<ThoughtBubble> {
    const newBubble: ThoughtBubble = { ...bubble, id: this.nextId++, userId };
    this.thoughtBubbles.push(newBubble);
    return newBubble;
  }

  async updateThoughtBubble(id: number, updates: Partial<ThoughtBubble>): Promise<ThoughtBubble> {
    const bubble = this.thoughtBubbles.find(bubble => bubble.id === id);
    if (bubble) {
      Object.assign(bubble, updates);
      return bubble;
    }
    throw new Error("Bubble not found");
  }

  async deleteThoughtBubble(id: number): Promise<void> {
    const index = this.thoughtBubbles.findIndex(bubble => bubble.id === id);
    if (index !== -1) {
      this.thoughtBubbles.splice(index, 1);
    }
  }

  async getScheduleEvents(userId: number, date: string): Promise<ScheduleEvent[]> {
    return this.scheduleEvents.filter(event => event.userId === userId && event.date === date);
  }

  async createScheduleEvent(userId: number, event: InsertScheduleEvent): Promise<ScheduleEvent> {
    const newEvent: ScheduleEvent = { ...event, id: this.nextId++, userId };
    this.scheduleEvents.push(newEvent);
    return newEvent;
  }

  async updateScheduleEvent(id: number, updates: Partial<ScheduleEvent>): Promise<ScheduleEvent> {
    const event = this.scheduleEvents.find(event => event.id === id);
    if (event) {
      Object.assign(event, updates);
      return event;
    }
    throw new Error("Event not found");
  }

  async deleteScheduleEvent(id: number): Promise<void> {
    const index = this.scheduleEvents.findIndex(event => event.id === id);
    if (index !== -1) {
      this.scheduleEvents.splice(index, 1);
    }
  }

  async getFavoriteQuotes(userId: number): Promise<FavoriteQuote[]> {
    return this.favoriteQuotes.filter(quote => quote.userId === userId);
  }

  async createFavoriteQuote(userId: number, quote: InsertFavoriteQuote): Promise<FavoriteQuote> {
    const newQuote: FavoriteQuote = { ...quote, id: this.nextId++, userId };
    this.favoriteQuotes.push(newQuote);
    return newQuote;
  }

  async deleteFavoriteQuote(id: number): Promise<void> {
    const index = this.favoriteQuotes.findIndex(quote => quote.id === id);
    if (index !== -1) {
      this.favoriteQuotes.splice(index, 1);
    }
  }
}

// Use in-memory storage instead of database
export const storage = new MemoryStorage();