import { useQuery } from "@tanstack/react-query";
import { useMood } from "@/hooks/useMood";
import { useJournal } from "@/hooks/useJournal";
import { usePlanner } from "@/hooks/usePlanner";
import { useBalance } from "@/hooks/useBalance";
import { subDays, format, startOfWeek, endOfWeek, isWithinInterval } from "date-fns";

export function useBalanceCalculations() {
  const { moodEntries } = useMood();
  const { journalEntries } = useJournal();
  const { wellness } = usePlanner();
  const { balanceEntries } = useBalance();

  // Calculate real balance scores based on user data
  const calculateBalanceScore = () => {
    if (!moodEntries.data || !wellness.data || !balanceEntries.data) {
      return { overallScore: 5, categoryScores: { academic: 5, social: 5, selfCare: 5, physical: 5 } };
    }

    const today = new Date();
    const weekStart = startOfWeek(today);
    const weekEnd = endOfWeek(today);

    // Get recent mood entries (last 7 days)
    const recentMoods = moodEntries.data.filter(entry => {
      const entryDate = new Date(entry.date);
      return isWithinInterval(entryDate, { start: subDays(today, 7), end: today });
    });

    // Get recent balance entries (last 7 days)
    const recentBalanceEntries = balanceEntries.data.filter(entry => {
      const entryDate = new Date(entry.date);
      return isWithinInterval(entryDate, { start: subDays(today, 7), end: today });
    });

    // Calculate average mood and energy
    const avgMoodScore = recentMoods.length > 0 
      ? recentMoods.reduce((sum, entry) => {
          // Convert mood to numeric score
          const moodScores: Record<string, number> = {
            'terrible': 1, 'sad': 2, 'meh': 3, 'happy': 4, 'energetic': 5,
            'anxious': 2, 'calm': 4, 'excited': 5, 'overwhelmed': 2, 'peaceful': 4
          };
          return sum + (moodScores[entry.mood] || 3);
        }, 0) / recentMoods.length
      : 5;

    const avgEnergyScore = recentMoods.length > 0
      ? recentMoods.reduce((sum, entry) => sum + entry.energy, 0) / recentMoods.length
      : 5;

    // Calculate wellness factors
    const currentWater = wellness.data.water || 0;
    const waterGoal = wellness.data.waterGoal || 8;
    const currentExercise = wellness.data.exercise || 0;
    const exerciseGoal = wellness.data.exerciseGoal || 45;
    const currentSleep = wellness.data.sleep || 0;

    const waterScore = Math.min((currentWater / waterGoal) * 10, 10);
    const exerciseScore = Math.min((currentExercise / exerciseGoal) * 10, 10);
    const sleepScore = currentSleep >= 7 ? 8 : currentSleep >= 6 ? 6 : currentSleep >= 5 ? 4 : 2;

    // Calculate category scores based on real data
    const physicalScore = (exerciseScore + sleepScore + waterScore) / 3;
    
    // Self-care score based on wellness tracking and mood stability
    const selfCareScore = (avgMoodScore + avgEnergyScore + (journalEntries.data?.length || 0 > 0 ? 2 : 0)) / 2;

    // Academic and social scores from recent balance entries
    const avgAcademic = recentBalanceEntries.length > 0
      ? recentBalanceEntries.reduce((sum, entry) => sum + entry.academic, 0) / recentBalanceEntries.length
      : 5;
    
    const avgSocial = recentBalanceEntries.length > 0
      ? recentBalanceEntries.reduce((sum, entry) => sum + entry.social, 0) / recentBalanceEntries.length
      : 5;

    const categoryScores = {
      academic: Math.round(avgAcademic * 10) / 10,
      social: Math.round(avgSocial * 10) / 10,
      selfCare: Math.round(selfCareScore * 10) / 10,
      physical: Math.round(physicalScore * 10) / 10,
    };

    const overallScore = Math.round(((categoryScores.academic + categoryScores.social + categoryScores.selfCare + categoryScores.physical) / 4) * 10) / 10;

    return { overallScore, categoryScores };
  };

  // Calculate weekly progress
  const calculateWeeklyProgress = () => {
    if (!balanceEntries.data || !moodEntries.data) {
      return [
        { week: "3 weeks ago", score: 6.0 },
        { week: "2 weeks ago", score: 6.5 },
        { week: "Last week", score: 7.2 }
      ];
    }

    const today = new Date();
    const weeks = [];

    for (let i = 2; i >= 0; i--) {
      const weekStart = startOfWeek(subDays(today, i * 7));
      const weekEnd = endOfWeek(subDays(today, i * 7));

      const weekMoods = moodEntries.data.filter(entry => {
        const entryDate = new Date(entry.date);
        return isWithinInterval(entryDate, { start: weekStart, end: weekEnd });
      });

      const weekBalance = balanceEntries.data.filter(entry => {
        const entryDate = new Date(entry.date);
        return isWithinInterval(entryDate, { start: weekStart, end: weekEnd });
      });

      let weekScore = 5; // default
      if (weekMoods.length > 0 && weekBalance.length > 0) {
        const avgMood = weekMoods.reduce((sum, entry) => sum + entry.energy, 0) / weekMoods.length;
        const avgBalance = weekBalance.reduce((sum, entry) => 
          sum + (entry.academic + entry.social + entry.selfCare + entry.physical) / 4, 0) / weekBalance.length;
        weekScore = (avgMood + avgBalance) / 2;
      }

      const weekLabel = i === 0 ? "This week" : i === 1 ? "Last week" : `${i + 1} weeks ago`;
      weeks.push({ week: weekLabel, score: Math.round(weekScore * 10) / 10 });
    }

    return weeks;
  };

  // Generate insights based on real data
  const generateInsights = () => {
    const { overallScore, categoryScores } = calculateBalanceScore();
    const insights = [];

    if (overallScore >= 7) {
      insights.push({ text: "🎉 Your balance is looking great this week!", color: "border-sage bg-sage/10" });
    } else if (overallScore >= 5) {
      insights.push({ text: "📈 You're making steady progress on your balance", color: "border-sky-custom bg-sky-custom/10" });
    } else {
      insights.push({ text: "🌱 Focus on small improvements each day", color: "border-pink-soft bg-pink-soft/10" });
    }

    // Category-specific insights
    const lowestCategory = Object.entries(categoryScores).reduce((min, [key, value]) => 
      value < min.value ? { key, value } : min, { key: '', value: 10 }
    );

    if (lowestCategory.key === 'physical') {
      insights.push({ text: "💪 Try adding 15 minutes of movement to your day", color: "border-pink-soft bg-pink-soft/10" });
    } else if (lowestCategory.key === 'selfCare') {
      insights.push({ text: "🧘 Schedule some self-care time this week", color: "border-lavender bg-lavender/10" });
    } else if (lowestCategory.key === 'social') {
      insights.push({ text: "👥 Consider reaching out to a friend today", color: "border-mint bg-mint/10" });
    } else if (lowestCategory.key === 'academic') {
      insights.push({ text: "📚 Break big tasks into smaller, manageable steps", color: "border-sky-custom bg-sky-custom/10" });
    }

    return insights;
  };

  return {
    balanceScore: calculateBalanceScore(),
    weeklyProgress: calculateWeeklyProgress(),
    insights: generateInsights(),
  };
}