import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Task, InsertTask, Wellness, ScheduleEvent, InsertScheduleEvent } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function usePlanner() {
  const { toast } = useToast();

  const tasks = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const wellness = useQuery<Wellness>({
    queryKey: ["/api/wellness/today"],
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache
  });

  const scheduleEvents = useQuery<ScheduleEvent[]>({
    queryKey: ["/api/schedule-events"],
  });

  const addTask = useMutation({
    mutationFn: async (data: InsertTask) => {
      const response = await apiRequest("POST", "/api/tasks", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task added! ✅",
        description: "New task has been added to your list.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to add task",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleTask = useMutation({
    mutationFn: async ({ id, completed }: { id: number; completed: boolean }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, { completed });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: () => {
      toast({
        title: "Failed to update task",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteTask = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted! 🗑️",
        description: "Task has been removed from your list.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete task",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateTask = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Task> }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: () => {
      toast({
        title: "Failed to update task",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateWellness = useMutation({
    mutationFn: async (updates: Partial<Wellness>) => {
      const response = await apiRequest("PATCH", "/api/wellness", updates);
      return response.json();
    },
    onSuccess: (data) => {
      // Force refresh of wellness data
      queryClient.setQueryData(["/api/wellness/today"], data);
      queryClient.removeQueries({ queryKey: ["/api/wellness/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wellness/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/balance"] });
    },
    onError: () => {
      toast({
        title: "Failed to update wellness data",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const addScheduleEvent = useMutation({
    mutationFn: async (data: InsertScheduleEvent) => {
      const response = await apiRequest("POST", "/api/schedule-events", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-events"] });
      toast({
        title: "Event added! 📅",
        description: "New event has been added to your schedule.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to add event",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateScheduleEvent = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<ScheduleEvent> }) => {
      const response = await apiRequest("PATCH", `/api/schedule-events/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-events"] });
    },
    onError: () => {
      toast({
        title: "Failed to update event",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteScheduleEvent = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/schedule-events/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedule-events"] });
      toast({
        title: "Event deleted! 🗑️",
        description: "Event has been removed from your schedule.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete event",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    tasks,
    wellness,
    scheduleEvents,
    addTask,
    toggleTask,
    deleteTask,
    updateTask,
    updateWellness,
    addScheduleEvent,
    updateScheduleEvent,
    deleteScheduleEvent,
  };
}
