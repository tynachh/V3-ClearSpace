import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { FavoriteQuote, InsertFavoriteQuote } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useFavoriteQuotes() {
  const { toast } = useToast();

  const favoriteQuotes = useQuery<FavoriteQuote[]>({
    queryKey: ["/api/favorite-quotes"],
  });

  const saveFavoriteQuote = useMutation({
    mutationFn: async (data: InsertFavoriteQuote) => {
      const response = await apiRequest("POST", "/api/favorite-quotes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorite-quotes"] });
      toast({
        title: "Quote saved! ✨",
        description: "Added to your favorite quotes collection.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to save quote",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteFavoriteQuote = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/favorite-quotes/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorite-quotes"] });
      toast({
        title: "Quote removed",
        description: "Removed from your favorites.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to remove quote",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    favoriteQuotes,
    saveFavoriteQuote,
    deleteFavoriteQuote,
  };
}