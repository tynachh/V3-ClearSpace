import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { BalanceEntry, InsertBalanceEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useBalance() {
  const { toast } = useToast();

  const balanceEntries = useQuery<BalanceEntry[]>({
    queryKey: ["/api/balance-entries"],
  });

  const saveBalanceEntry = useMutation({
    mutationFn: async (data: InsertBalanceEntry) => {
      const response = await apiRequest("POST", "/api/balance-entries", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/balance-entries"] });
      toast({
        title: "Balance updated! ⚖️",
        description: "Your life balance has been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to save balance",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    balanceEntries,
    saveBalanceEntry,
  };
}
