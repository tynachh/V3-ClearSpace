import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { MoodEntry, InsertMoodEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useMood() {
  const { toast } = useToast();

  const moodEntries = useQuery<MoodEntry[]>({
    queryKey: ["/api/mood-entries"],
  });

  const saveMoodEntry = useMutation({
    mutationFn: async (data: InsertMoodEntry) => {
      const response = await apiRequest("POST", "/api/mood-entries", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-entries"] });
      toast({
        title: "Mood saved! 🌟",
        description: "Your mood check-in has been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to save mood",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    moodEntries,
    saveMoodEntry,
  };
}
