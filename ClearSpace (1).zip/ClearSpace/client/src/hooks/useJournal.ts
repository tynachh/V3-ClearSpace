import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { JournalEntry, InsertJournalEntry } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useJournal() {
  const { toast } = useToast();

  const journalEntries = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal-entries"],
  });

  const saveJournalEntry = useMutation({
    mutationFn: async (data: InsertJournalEntry) => {
      const response = await apiRequest("POST", "/api/journal-entries", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      toast({
        title: "Journal entry saved! ✨",
        description: "Your thoughts have been captured.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to save entry",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteJournalEntry = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/journal-entries/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      toast({
        title: "Entry deleted",
        description: "Journal entry has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to delete entry",
        description: "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    journalEntries,
    saveJournalEntry,
    deleteJournalEntry,
  };
}
