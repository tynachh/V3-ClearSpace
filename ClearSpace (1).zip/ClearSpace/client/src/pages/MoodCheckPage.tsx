import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useMood } from "@/hooks/useMood";
import { cn } from "@/lib/utils";

const moods = [
  { id: "energetic", emoji: "⚡", label: "Energetic" },
  { id: "calm", emoji: "🧘", label: "Calm" },
  { id: "stressed", emoji: "😰", label: "Stressed" },
  { id: "tired", emoji: "😴", label: "Tired" },
  { id: "anxious", emoji: "😟", label: "Anxious" },
  { id: "happy", emoji: "😊", label: "Happy" },
  { id: "overwhelmed", emoji: "🤯", label: "Overwhelmed" },
  { id: "focused", emoji: "🎯", label: "Focused" },
];

const moodInsights = {
  energetic: {
    title: "You're feeling energetic! ⚡",
    description: "Perfect time for tackling challenging tasks and being productive.",
    suggestions: ["Schedule important tasks now", "Use this energy for physical activity", "Take on creative projects"]
  },
  calm: {
    title: "You're in a calm state 🧘",
    description: "Great for reflection, deep work, and mindful activities.",
    suggestions: ["Perfect time for studying", "Try some journaling", "Engage in creative activities"]
  },
  stressed: {
    title: "Feeling stressed 😰",
    description: "Let's create a gentle schedule to help you feel more centered.",
    suggestions: ["Start with a breathing exercise", "Break tasks into smaller steps", "Schedule self-care breaks"]
  },
  tired: {
    title: "You're feeling tired 😴",
    description: "Let's plan a lighter day with restorative activities.",
    suggestions: ["Prioritize rest and easy tasks", "Include gentle movement", "Early bedtime tonight"]
  },
  anxious: {
    title: "Feeling anxious 😟",
    description: "Let's create a supportive schedule to help you feel grounded.",
    suggestions: ["Start with calming activities", "Include breathing exercises", "Connect with supportive people"]
  },
  happy: {
    title: "You're feeling happy! 😊",
    description: "Wonderful! Let's make the most of this positive energy.",
    suggestions: ["Share this joy with others", "Work on meaningful projects", "Celebrate small wins"]
  },
  overwhelmed: {
    title: "Feeling overwhelmed 🤯",
    description: "Let's simplify your day and focus on what truly matters.",
    suggestions: ["Prioritize only essential tasks", "Take regular breaks", "Ask for help when needed"]
  },
  focused: {
    title: "You're feeling focused! 🎯",
    description: "Perfect for deep work and important projects.",
    suggestions: ["Tackle your most important task first", "Use time-blocking", "Minimize distractions"]
  }
};

const MoodCheckPage = () => {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [energy, setEnergy] = useState(5);
  const { saveMoodEntry } = useMood();

  // Daily motivational quotes
  const dailyQuotes = [
    "It's okay to not be okay - your feelings are valid",
    "You're doing better than you think you are",
    "Small progress is still progress - be proud of yourself",
    "Your mood right now is temporary - this too shall pass",
    "Taking time to check in with yourself is self-care",
    "You have the strength to handle whatever today brings",
    "Your mental health matters more than anything else"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
  };

  const handleSaveMood = () => {
    if (selectedMood) {
      saveMoodEntry.mutate({ mood: selectedMood, energy });
    }
  };

  const selectedMoodData = selectedMood ? moodInsights[selectedMood as keyof typeof moodInsights] : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 relative">
      {/* Floating decorative elements - edge positioned */}
      <div className="absolute top-4 left-4 w-12 h-12 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 55%, 68%)', opacity: 0.3}}></div>
      <div className="absolute top-16 right-4 w-8 h-8 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.4, animationDelay: '1s'}}></div>
      <div className="absolute bottom-4 left-4 w-16 h-16 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.35, animationDelay: '2s'}}></div>
      <div className="absolute top-32 right-8 w-10 h-10 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.45, animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-16 right-4 w-14 h-14 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.3, animationDelay: '1.5s'}}></div>
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How are you feeling today?</h1>
        <p className="text-lg text-muted-foreground">Let's check in with your mood and create a day that works for you</p>
      </div>

      {/* Mood Selection */}
      <Card className="bg-card rounded-3xl shadow-sm border border-border mb-8">
        <CardContent className="p-8">
          <h2 className="text-xl font-semibold text-foreground mb-6">Choose your current mood:</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {moods.map((mood) => (
              <Button
                key={mood.id}
                variant="outline"
                className={cn(
                  "p-6 h-auto rounded-2xl border-2 transition-all duration-200 text-center flex flex-col items-center space-y-2",
                  selectedMood === mood.id
                    ? "border-sage bg-sage/10 dark:bg-sage/20"
                    : "border-sage/20 dark:border-sage/40 hover:border-sage"
                )}
                onClick={() => handleMoodSelect(mood.id)}
              >
                <div className="text-3xl">{mood.emoji}</div>
                <div className="font-medium text-foreground">{mood.label}</div>
              </Button>
            ))}
          </div>

          {/* Energy Level */}
          <div className="mt-8">
            <h3 className="text-lg font-semibold text-foreground mb-4">Energy Level (1-10):</h3>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-muted-foreground">Low</span>
              <input
                type="range"
                min="1"
                max="10"
                value={energy}
                onChange={(e) => setEnergy(Number(e.target.value))}
                className="flex-1 h-2 bg-sage/20 dark:bg-sage/30 rounded-lg appearance-none cursor-pointer slider"
              />
              <span className="text-sm text-muted-foreground">High</span>
              <span className="text-lg font-semibold text-sage min-w-[2rem]">{energy}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mood Insights */}
      {selectedMoodData && (
        <Card className="bg-gradient-to-r from-sage/10 to-mint/10 dark:from-sage/15 dark:to-mint/15 rounded-3xl border border-sage/20 dark:border-sage/40 mb-8 animate-fade-in">
          <CardContent className="p-8">
            <h3 className="text-xl font-semibold text-foreground mb-4">Your personalized insights:</h3>
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-foreground">{selectedMoodData.title}</h4>
              <p className="text-muted-foreground">{selectedMoodData.description}</p>
              <div className="space-y-2">
                <h5 className="font-medium text-foreground">Suggested activities:</h5>
                <ul className="space-y-2">
                  {selectedMoodData.suggestions.map((suggestion, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-sage rounded-full"></div>
                      <span className="text-sm text-muted-foreground">{suggestion}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="flex gap-4 mt-6">
              <Button 
                onClick={handleSaveMood}
                disabled={saveMoodEntry.isPending}
                className="bg-gradient-to-r from-sage to-sage-dark text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all duration-200"
              >
                {saveMoodEntry.isPending ? "Saving..." : "Save Mood Check"}
              </Button>
              <Link href="/planner">
                <Button variant="outline" className="px-6 py-3 rounded-full font-medium border-sage hover:bg-sage/10 dark:hover:bg-sage/20 transition-all duration-200">
                  Create Your Day Plan
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="bg-card rounded-2xl shadow-sm border border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Quick Meditation</h3>
            <p className="text-muted-foreground mb-4">5-minute breathing exercise</p>
            <Link href="/meditation">
              <Button className="bg-sage/20 dark:bg-sage/30 text-sage px-4 py-2 rounded-full text-sm font-medium hover:bg-sage/30 dark:hover:bg-sage/40 transition-colors">
                Start Now
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-card rounded-2xl shadow-sm border border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Brain Dump</h3>
            <p className="text-muted-foreground mb-4">Clear your mind on paper</p>
            <Link href="/journal">
              <Button className="bg-pink-soft/20 dark:bg-pink-soft/30 text-pink-soft px-4 py-2 rounded-full text-sm font-medium hover:bg-pink-soft/30 dark:hover:bg-pink-soft/40 transition-colors">
                Write Now
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-card rounded-2xl shadow-sm border border-border">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-3">Daily Affirmation</h3>
            <p className="text-muted-foreground mb-4">"You are capable of amazing things." ✨</p>
            <Button className="bg-lavender/20 dark:bg-lavender/30 text-lavender px-4 py-2 rounded-full text-sm font-medium hover:bg-lavender/30 dark:hover:bg-lavender/40 transition-colors">
              New Quote
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-sage/10 to-mint/10 rounded-3xl border border-sage/20 inline-block">
          <CardContent className="p-6">
            <p className="text-soft-charcoal/80 italic text-lg">
              {getDailyQuote()}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MoodCheckPage;
