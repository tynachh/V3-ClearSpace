import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, RotateCcw, Wind, Brain, Moon } from "lucide-react";

const quickSessions = [
  {
    id: "quick-calm",
    title: "Quick Calm",
    duration: "5 minutes",
    description: "Perfect for between classes or when you need a quick reset",
    icon: Wind,
    color: "from-sage/20 to-mint/20",
    borderColor: "border-sage/30",
    buttonColor: "bg-sage hover:bg-sage-dark"
  },
  {
    id: "focus-flow",
    title: "Focus Flow",
    duration: "10 minutes", 
    description: "Boost concentration before studying or important tasks",
    icon: Brain,
    color: "from-sky-custom/20 to-sky-light/20",
    borderColor: "border-sky-custom/30",
    buttonColor: "bg-sky-custom hover:bg-sky-light"
  },
  {
    id: "sleep-prep",
    title: "Sleep Prep",
    duration: "15 minutes",
    description: "Wind down and prepare for restful sleep",
    icon: Moon,
    color: "from-lavender/20 to-pink-soft/20",
    borderColor: "border-lavender/30",
    buttonColor: "bg-lavender hover:bg-pink-soft"
  }
];



const MeditationPage = () => {
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [selectedDuration, setSelectedDuration] = useState(5); // 5 minutes default
  const [breathText, setBreathText] = useState("Breathe");
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [sessionPhase, setSessionPhase] = useState("");
  const [motivationalQuote, setMotivationalQuote] = useState("");

  // Daily motivational quotes
  const dailyQuotes = [
    "Breathe in peace, breathe out stress - you're exactly where you need to be 🧘",
    "Every moment of stillness is a gift you give yourself ✨",
    "Your mind is like the sky - clouds of thoughts will pass 💙",
    "In this moment, you are enough, you have enough, you do enough 🌱",
    "Meditation isn't about stopping thoughts - it's about observing them 💜",
    "Find peace in the present moment - it's the only one that exists 🌟",
    "Your breath is your anchor to the present moment 🤗"
  ];

  // Sleep prep motivational quotes
  const sleepQuotes = [
    "You've done enough today - now let yourself rest 🌙",
    "Tomorrow is a fresh start, tonight is for peace ✨",
    "Your mind and body deserve this gentle rest 💙",
    "Let go of today's worries - they can wait until tomorrow 🌱",
    "You are safe, you are loved, you are enough 💜",
    "Each breath brings you deeper into peaceful sleep 🤗",
    "Rest is not a luxury, it's a necessity for your wellbeing 🌟",
    "Allow yourself to sink into the comfort of this moment 💤"
  ];

  // Focus flow exercises
  const focusExercises = {
    breathing: {
      title: "Box Breathing",
      instruction: "Breathe in for 4, hold for 4, out for 4, hold for 4",
      duration: 2
    },
    mindDump: {
      title: "Brain Dump",
      instruction: "Let all your thoughts flow out - write them down or just think them through",
      duration: 3
    },
    movement: {
      title: "Gentle Movement",
      instruction: "Stretch your neck, roll your shoulders, wiggle your fingers",
      activities: [
        "Roll your shoulders backwards 5 times",
        "Stretch your neck side to side",
        "Take 3 deep breaths with arm raises", 
        "Wiggle your fingers and toes",
        "Gentle neck rolls (3 each direction)",
        "Shoulder blade squeezes (hold for 5 seconds)"
      ]
    }
  };

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  useEffect(() => {
    // Timer countdown
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => {
          const newSeconds = prev - 1;
          
          // Handle session-specific logic
          if (activeSession === "focus-flow") {
            const totalDuration = 10 * 60; // 10 minutes
            const elapsed = totalDuration - newSeconds;
            
            if (elapsed === 0) {
              setSessionPhase("Box Breathing - Reset Your Breath");
            } else if (elapsed === 2 * 60) {
              setSessionPhase("Brain Dump - Clear Your Mind Fast");
            } else if (elapsed === 5 * 60) {
              setSessionPhase("Gentle Movement - Move Your Body");
            }
          } else if (activeSession === "sleep-prep") {
            // Show new quote every minute for sleep prep
            const elapsed = selectedDuration * 60 - newSeconds;
            if (elapsed > 0 && elapsed % 60 === 0) {
              const randomQuote = sleepQuotes[Math.floor(Math.random() * sleepQuotes.length)];
              setMotivationalQuote(randomQuote);
            }
          }
          
          return newSeconds;
        });
      }, 1000);
    } else if (timerSeconds === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      setActiveSession(null);
      setSessionPhase("");
      setMotivationalQuote("");
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSeconds, activeSession, selectedDuration]);

  useEffect(() => {
    // Breathing animation cycle
    const breathingCycle = setInterval(() => {
      setBreathText(prev => {
        switch(prev) {
          case "Breathe": return "Inhale";
          case "Inhale": return "Hold";
          case "Hold": return "Exhale";
          case "Exhale": return "Breathe";
          default: return "Breathe";
        }
      });
    }, 4000);

    return () => clearInterval(breathingCycle);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const startTimer = (minutes: number) => {
    setSelectedDuration(minutes);
    setTimerSeconds(minutes * 60);
    setIsTimerRunning(true);
  };

  const startSession = (sessionId: string) => {
    let duration = 5; // default
    
    if (sessionId === "quick-calm") {
      duration = 5;
      setSessionPhase("5-Minute Breathing Exercise for Focus");
    } else if (sessionId === "focus-flow") {
      duration = 10;
      setSessionPhase("Box Breathing - Reset Your Breath");
    } else if (sessionId === "sleep-prep") {
      duration = 15;
      setSessionPhase("Peaceful Breathing for Sleep");
      setMotivationalQuote(sleepQuotes[0]);
    }
    
    setActiveSession(sessionId);
    setSelectedDuration(duration);
    setTimerSeconds(duration * 60);
    setIsTimerRunning(true);
  };

  const toggleTimer = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimerSeconds(selectedDuration * 60);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 relative">
      {/* Floating decorative elements */}
      <div className="absolute top-20 left-12 w-16 h-16 rounded-full animate-float" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.35}}></div>
      <div className="absolute top-48 right-8 w-10 h-10 rounded-full animate-float" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.45, animationDelay: '1s'}}></div>
      <div className="absolute bottom-24 left-8 w-12 h-12 rounded-full animate-float" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.4, animationDelay: '2s'}}></div>
      <div className="absolute top-72 right-16 w-8 h-8 rounded-full animate-float" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.5, animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-48 right-20 w-14 h-14 rounded-full animate-float" style={{backgroundColor: 'hsl(163, 55%, 68%)', opacity: 0.35, animationDelay: '1.5s'}}></div>
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground dark:text-white mb-4">Guided Meditation & Breathing</h1>
        <p className="text-lg text-muted-foreground dark:text-gray-300">Ground yourself with soothing sessions tailored for students</p>
      </div>

      {/* Quick Sessions */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {quickSessions.map((session) => {
          const IconComponent = session.icon;
          return (
            <Card key={session.id} className={`bg-gradient-to-br ${session.color} dark:bg-gray-800 rounded-3xl border ${session.borderColor} dark:border-gray-600`}>
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-sage rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground dark:text-white mb-2">{session.title}</h3>
                  <p className="text-muted-foreground dark:text-gray-300 text-sm">{session.duration}</p>
                </div>
                <p className="text-muted-foreground dark:text-gray-300 mb-6 text-center">{session.description}</p>
                <Button 
                  onClick={() => startSession(session.id)}
                  className={`w-full ${session.buttonColor} text-black dark:text-black py-3 rounded-full font-medium transition-colors`}
                >
                  <Play className="w-4 h-4 mr-2" />
                  Start Session
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Active Session Player */}
      <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border mb-8">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-semibold text-foreground dark:text-white mb-2">
              {activeSession ? sessionPhase : "Breathing Exercise"}
            </h3>
            <p className="text-muted-foreground dark:text-gray-300">
              {activeSession === "focus-flow" ? "Follow the phases to boost your concentration" :
               activeSession === "quick-calm" ? "5 minutes of focused breathing for quick calm" :
               activeSession === "sleep-prep" ? "Gentle breathing to prepare for restful sleep" :
               "Follow the rhythm and breathe deeply"}
            </p>
          </div>

          {/* Session-specific content */}
          {activeSession === "focus-flow" && sessionPhase.includes("Movement") && (
            <div className="mb-6 p-4 bg-gradient-to-r from-mint/10 to-sage/10 rounded-2xl border border-mint/20">
              <h4 className="font-semibold text-soft-charcoal mb-3">💧 Remember to hydrate!</h4>
              <p className="text-sm text-soft-charcoal/80 mb-4">Take a sip of water between movements</p>
              <h4 className="font-semibold text-soft-charcoal mb-3">Gentle Movement Ideas:</h4>
              <div className="grid grid-cols-2 gap-2 text-sm text-soft-charcoal/80">
                {focusExercises.movement.activities.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-mint rounded-full"></span>
                    <span>{activity}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeSession === "sleep-prep" && motivationalQuote && (
            <div className="mb-6 p-6 bg-gradient-to-r from-lavender/10 to-pink-soft/10 rounded-2xl border border-lavender/20 text-center">
              <div className="text-lg text-soft-charcoal font-medium leading-relaxed">
                {motivationalQuote}
              </div>
            </div>
          )}

          {/* Breathing Animation */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              <div className="w-32 h-32 bg-gradient-to-br from-sage to-mint rounded-full animate-pulse-gentle flex items-center justify-center">
                <div className="w-20 h-20 bg-warm-white rounded-full flex items-center justify-center">
                  <span className="text-sage font-semibold">{breathText}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Timer Controls */}
          <div className="flex justify-center items-center space-x-4 mb-8">
            <Button 
              onClick={() => startTimer(5)}
              variant={selectedDuration === 5 ? "default" : "outline"}
              className="px-4 py-2 rounded-full"
            >
              5 min
            </Button>
            <Button 
              onClick={() => startTimer(10)}
              variant={selectedDuration === 10 ? "default" : "outline"}
              className="px-4 py-2 rounded-full"
            >
              10 min
            </Button>
            <Button 
              onClick={() => startTimer(15)}
              variant={selectedDuration === 15 ? "default" : "outline"}
              className="px-4 py-2 rounded-full"
            >
              15 min
            </Button>
          </div>

          {/* Timer Display */}
          <div className="text-center mb-6">
            <div className="text-4xl font-bold text-sage mb-4">
              {formatTime(timerSeconds)}
            </div>
            <div className="flex justify-center space-x-4">
              <Button 
                onClick={toggleTimer}
                className="bg-gradient-to-r from-sage to-sage-dark text-white px-6 py-3 rounded-full"
              >
                {isTimerRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {isTimerRunning ? "Pause" : "Start"}
              </Button>
              <Button 
                onClick={resetTimer}
                variant="outline"
                className="px-6 py-3 rounded-full"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-lavender/10 to-mint/10 rounded-3xl border border-lavender/20 inline-block">
          <CardContent className="p-6">
            <p className="text-soft-charcoal/80 italic text-lg">
              {getDailyQuote()}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MeditationPage;
