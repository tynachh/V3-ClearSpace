import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useFavoriteQuotes } from "@/hooks/useFavoriteQuotes";
import { Star, Trash2, Heart } from "lucide-react";
import { format } from "date-fns";

const FavoritesPage = () => {
  const { favoriteQuotes, deleteFavoriteQuote } = useFavoriteQuotes();

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 relative">
      {/* Floating decorative elements */}
      <div className="absolute top-4 left-4 w-12 h-12 bg-mint/40 rounded-full animate-float pointer-events-none"></div>
      <div className="absolute top-16 right-4 w-16 h-16 bg-pink-soft/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-4 left-4 w-10 h-10 bg-lavender/45 rounded-full animate-float pointer-events-none" style={{animationDelay: '2s'}}></div>
      <div className="absolute top-32 right-8 w-8 h-8 bg-sage/40 rounded-full animate-float pointer-events-none" style={{animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-16 right-4 w-14 h-14 bg-sky-custom/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '1.5s'}}></div>

      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground dark:text-white mb-4">Favorite Quotes</h1>
        <p className="text-lg text-muted-foreground dark:text-gray-300">Your collection of inspiring quotes and affirmations</p>
      </div>

      {favoriteQuotes.isLoading ? (
        <div className="text-center py-12">
          <div className="text-soft-charcoal/60">Loading your favorite quotes...</div>
        </div>
      ) : favoriteQuotes.data && favoriteQuotes.data.length > 0 ? (
        <div className="space-y-6">
          {favoriteQuotes.data.map((quote) => (
            <Card key={quote.id} className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <blockquote className="text-foreground dark:text-white italic text-lg leading-relaxed mb-3">
                      "{quote.quote}"
                    </blockquote>
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-muted-foreground dark:text-gray-300">
                        {quote.source && (
                          <span className="text-sage font-medium">— {quote.source}</span>
                        )}
                        {quote.dateAdded && (
                          <span className="ml-2">
                            Saved on {format(new Date(quote.dateAdded), "MMM d, yyyy")}
                          </span>
                        )}
                      </div>
                      <Button
                        onClick={() => deleteFavoriteQuote.mutate(quote.id)}
                        disabled={deleteFavoriteQuote.isPending}
                        variant="ghost"
                        size="sm"
                        className="text-muted-foreground dark:text-gray-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-sage/20 to-mint/20 rounded-full flex items-center justify-center mb-6">
              <Star className="w-8 h-8 text-sage" />
            </div>
            <h3 className="text-xl font-semibold text-foreground dark:text-white mb-3">No favorites yet</h3>
            <p className="text-muted-foreground dark:text-gray-300 max-w-md mx-auto mb-6">
              Start saving quotes that inspire you! Look for the "Save Quote" buttons on the Balance and Planner pages.
            </p>
            <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground dark:text-gray-400">
              <div className="flex items-center space-x-1">
                <Heart className="w-4 h-4 text-lavender" />
                <span>Daily Affirmations</span>
              </div>
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 text-sage" />
                <span>Balance Wisdom</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default FavoritesPage;