import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { usePlanner } from "@/hooks/usePlanner";
import { useFavoriteQuotes } from "@/hooks/useFavoriteQuotes";
import { format } from "date-fns";
import { Plus, Play, RotateCcw, Heart, Pause, Edit2, Save, X, Trash2, Clock, Calendar, Droplets } from "lucide-react";

const PlannerPage = () => {
  const [timerTime, setTimerTime] = useState(25 * 60); // 25 minutes in seconds
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newEventTitle, setNewEventTitle] = useState("");
  const [newEventDescription, setNewEventDescription] = useState("");
  const [newEventTime, setNewEventTime] = useState("");
  const [editingTask, setEditingTask] = useState<number | null>(null);
  const [editingEvent, setEditingEvent] = useState<number | null>(null);
  const [editTaskTitle, setEditTaskTitle] = useState("");
  const [editEventTitle, setEditEventTitle] = useState("");
  const [editEventDescription, setEditEventDescription] = useState("");
  const [editEventTime, setEditEventTime] = useState("");
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [wellnessEditing, setWellnessEditing] = useState<string | null>(null);
  
  const { 
    tasks, 
    wellness, 
    scheduleEvents, 
    toggleTask, 
    addTask, 
    deleteTask, 
    updateTask,
    updateWellness,
    addScheduleEvent,
    updateScheduleEvent,
    deleteScheduleEvent
  } = usePlanner();

  const { saveFavoriteQuote } = useFavoriteQuotes();

  // Daily motivational quotes
  const dailyQuotes = [
    "Planning isn't about perfection - it's about intention and self-care",
    "Your energy is precious - plan to protect and nurture it",
    "Small, mindful steps create sustainable progress", 
    "It's okay to adjust your plans as your needs change",
    "You don't have to do everything today - prioritize what matters most",
    "Rest and breaks are productive parts of your plan",
    "You're capable of creating a day that serves your wellbeing"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerRunning && timerTime > 0) {
      interval = setInterval(() => {
        setTimerTime((prev) => prev - 1);
      }, 1000);
    } else if (timerTime === 0) {
      setIsTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerTime]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const toggleTimer = () => {
    setIsTimerRunning(!isTimerRunning);
  };

  const resetTimer = () => {
    setIsTimerRunning(false);
    setTimerTime(25 * 60);
  };

  // Helper functions
  const handleAddTask = () => {
    if (newTaskTitle.trim()) {
      addTask.mutate({ title: newTaskTitle.trim() });
      setNewTaskTitle("");
    }
  };

  const handleEditTask = (taskId: number) => {
    const task = tasks.data?.find(t => t.id === taskId);
    if (task) {
      setEditingTask(taskId);
      setEditTaskTitle(task.title);
    }
  };

  const handleSaveTask = () => {
    if (editingTask && editTaskTitle.trim()) {
      updateTask.mutate({ 
        id: editingTask, 
        updates: { title: editTaskTitle.trim() }
      });
      setEditingTask(null);
      setEditTaskTitle("");
    }
  };

  const handleDeleteTask = (taskId: number) => {
    deleteTask.mutate(taskId);
  };

  const handleAddEvent = () => {
    if (newEventTitle.trim() && newEventTime) {
      const today = format(new Date(), "yyyy-MM-dd");
      addScheduleEvent.mutate({
        title: newEventTitle.trim(),
        description: newEventDescription.trim() || undefined,
        time: newEventTime,
        date: today,
        color: "sage"
      });
      setNewEventTitle("");
      setNewEventDescription("");
      setNewEventTime("");
      setShowAddEvent(false);
    }
  };

  const handleEditEvent = (eventId: number) => {
    const event = scheduleEvents.data?.find(e => e.id === eventId);
    if (event) {
      setEditingEvent(eventId);
      setEditEventTitle(event.title);
      setEditEventDescription(event.description || "");
      setEditEventTime(event.time);
    }
  };

  const handleSaveEvent = () => {
    if (editingEvent && editEventTitle.trim() && editEventTime) {
      updateScheduleEvent.mutate({
        id: editingEvent,
        updates: {
          title: editEventTitle.trim(),
          description: editEventDescription.trim() || undefined,
          time: editEventTime
        }
      });
      setEditingEvent(null);
      setEditEventTitle("");
      setEditEventDescription("");
      setEditEventTime("");
    }
  };

  const handleDeleteEvent = (eventId: number) => {
    deleteScheduleEvent.mutate(eventId);
  };

  const handleWellnessUpdate = (field: string, value: number | string) => {
    const today = format(new Date(), "yyyy-MM-dd");
    updateWellness.mutate({ 
      [field]: value,
      date: today
    });
  };

  const currentWater = wellness.data?.water || 0;
  const currentExercise = wellness.data?.exercise || 0;
  const currentSleep = wellness.data?.sleep || 0;
  const waterGoal = wellness.data?.waterGoal || 8;
  const exerciseGoal = wellness.data?.exerciseGoal || 45;
  const bedtime = wellness.data?.bedtime || "10:00 PM";
  const wakeTime = wellness.data?.wakeTime || "7:00 AM";

  return (
    <div className="min-h-screen bg-gradient-to-br from-sage/5 via-warm-white to-mint/10 relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-4 py-12 relative">
        {/* Enhanced Floating decorative elements - positioned to avoid text overlap */}
        <div className="absolute top-4 left-4 w-12 h-12 bg-mint/40 rounded-full animate-float pointer-events-none"></div>
        <div className="absolute top-16 right-4 w-16 h-16 bg-pink-soft/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-4 left-4 w-10 h-10 bg-lavender/45 rounded-full animate-float pointer-events-none" style={{animationDelay: '2s'}}></div>
        <div className="absolute top-32 right-16 w-8 h-8 bg-sage/40 rounded-full animate-float pointer-events-none" style={{animationDelay: '0.5s'}}></div>
        <div className="absolute bottom-16 right-4 w-14 h-14 bg-sky-custom/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '1.5s'}}></div>
        
        {/* Additional colorful animated bubbles - edge positioned */}
        <div className="absolute top-8 left-2 w-6 h-6 bg-purple-400/30 rounded-full animate-float pointer-events-none" style={{animationDelay: '3s'}}></div>
        <div className="absolute top-48 right-2 w-20 h-20 bg-teal-300/25 rounded-full animate-float pointer-events-none" style={{animationDelay: '4s'}}></div>
        <div className="absolute bottom-32 left-2 w-12 h-12 bg-yellow-300/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '2.5s'}}></div>
        <div className="absolute top-24 left-8 w-4 h-4 bg-rose-300/40 rounded-full animate-float pointer-events-none" style={{animationDelay: '1.8s'}}></div>
        <div className="absolute bottom-48 right-8 w-8 h-8 bg-indigo-300/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '3.2s'}}></div>
        <div className="absolute top-64 left-8 w-18 h-18 bg-emerald-300/25 rounded-full animate-float pointer-events-none" style={{animationDelay: '4.5s'}}></div>
      
        <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground dark:text-white mb-4">Your Personal Planner</h1>
        <p className="text-lg text-muted-foreground dark:text-gray-300">Plan your day with intention and track your wellness goals</p>
      </div>

      {/* Today's Overview */}
      <Card className="bg-gradient-to-r from-sage/10 to-mint/10 dark:from-sage/20 dark:to-mint/20 dark:bg-gray-800 rounded-3xl border border-sage/20 dark:border-sage/40 mb-8">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div>
              <h2 className="text-2xl font-semibold text-foreground dark:text-white mb-2">
                Today, {format(new Date(), "MMMM d")}
              </h2>
              <p className="text-muted-foreground dark:text-gray-300">{format(new Date(), "EEEE")} • Week {format(new Date(), "w")} of {format(new Date(), "yyyy")}</p>
            </div>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <div className="text-center">
                <div className="text-2xl font-bold text-sage">😊</div>
                <div className="text-xs text-soft-charcoal/80">Mood</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-sky-custom">8/10</div>
                <div className="text-xs text-soft-charcoal/80">Energy</div>
              </div>
            </div>
          </div>

          {/* Quick Stats - Editable */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="bg-warm-white rounded-2xl p-4 group hover:bg-sage/5 transition-colors cursor-pointer"
                 onClick={() => setWellnessEditing(wellnessEditing === "water" ? null : "water")}>
              <div className="text-center">
                {wellnessEditing === "water" ? (
                  <div className="space-y-2">
                    <Input 
                      type="number"
                      value={currentWater}
                      onChange={(e) => {
                        const newValue = parseInt(e.target.value) || 0;
                        handleWellnessUpdate("water", newValue);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          setWellnessEditing(null);
                        }
                      }}
                      onBlur={() => setWellnessEditing(null)}
                      className="text-center text-lg font-bold border-sky-custom/30"
                      min="0"
                      max="20"
                      autoFocus
                    />
                    <div className="text-sm text-soft-charcoal/80">/ {waterGoal} glasses</div>
                  </div>
                ) : (
                  <>
                    <div className="text-lg font-bold text-sky-custom flex items-center justify-center gap-2">
                      <Droplets className="w-5 h-5" />
                      {currentWater}/{waterGoal}
                    </div>
                    <div className="text-sm text-soft-charcoal/80">Water Glasses</div>
                  </>
                )}
              </div>
            </div>
            
            <div className="bg-warm-white rounded-2xl p-4 group hover:bg-pink-soft/5 transition-colors cursor-pointer"
                 onClick={() => setWellnessEditing(wellnessEditing === "exercise" ? null : "exercise")}>
              <div className="text-center">
                {wellnessEditing === "exercise" ? (
                  <div className="space-y-2">
                    <Input 
                      type="number"
                      value={currentExercise}
                      onChange={(e) => {
                        const newValue = parseInt(e.target.value) || 0;
                        handleWellnessUpdate("exercise", newValue);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          setWellnessEditing(null);
                        }
                      }}
                      onBlur={() => setWellnessEditing(null)}
                      className="text-center text-lg font-bold border-pink-soft/30"
                      min="0"
                      max="300"
                      autoFocus
                    />
                    <div className="text-sm text-soft-charcoal/80">minutes</div>
                  </div>
                ) : (
                  <>
                    <div className="text-lg font-bold text-pink-soft flex items-center justify-center gap-2">
                      <Heart className="w-5 h-5" />
                      {currentExercise}
                    </div>
                    <div className="text-sm text-soft-charcoal/80">Exercise Minutes</div>
                  </>
                )}
              </div>
            </div>
            
            <div className="bg-warm-white rounded-2xl p-4 group hover:bg-lavender/5 transition-colors cursor-pointer"
                 onClick={() => setWellnessEditing(wellnessEditing === "sleep" ? null : "sleep")}>
              <div className="text-center">
                {wellnessEditing === "sleep" ? (
                  <div className="space-y-2">
                    <Input 
                      type="number"
                      step="0.5"
                      value={currentSleep}
                      onChange={(e) => {
                        const newValue = parseFloat(e.target.value) || 0;
                        handleWellnessUpdate("sleep", newValue);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          setWellnessEditing(null);
                        }
                      }}
                      onBlur={() => setWellnessEditing(null)}
                      className="text-center text-lg font-bold border-lavender/30"
                      min="0"
                      max="12"
                      autoFocus
                    />
                    <div className="text-sm text-soft-charcoal/80">hours</div>
                  </div>
                ) : (
                  <>
                    <div className="text-lg font-bold text-lavender">{currentSleep}</div>
                    <div className="text-sm text-soft-charcoal/80">Sleep Hours</div>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: Schedule & Tasks */}
        <div className="lg:col-span-2 space-y-8">
          {/* Today's Schedule - Editable */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-foreground dark:text-white">Today's Schedule</h3>
                <Button 
                  onClick={() => setShowAddEvent(!showAddEvent)}
                  className="bg-sage/20 text-sage px-4 py-2 rounded-full text-sm font-medium hover:bg-sage/30 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Event
                </Button>
              </div>

              {/* Add Event Form */}
              {showAddEvent && (
                <div className="mb-6 p-4 bg-sage/5 rounded-2xl border border-sage/20">
                  <div className="space-y-3">
                    <Input
                      placeholder="Event title"
                      value={newEventTitle}
                      onChange={(e) => setNewEventTitle(e.target.value)}
                      className="border-sage/30"
                    />
                    <Input
                      placeholder="Description (optional)"
                      value={newEventDescription}
                      onChange={(e) => setNewEventDescription(e.target.value)}
                      className="border-sage/30"
                    />
                    <div className="flex gap-2">
                      <Input
                        type="time"
                        value={newEventTime}
                        onChange={(e) => setNewEventTime(e.target.value)}
                        className="border-sage/30 flex-1"
                      />
                      <Button onClick={handleAddEvent} className="bg-sage text-white px-6">
                        <Save className="w-4 h-4 mr-2" />
                        Save
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setShowAddEvent(false);
                          setNewEventTitle("");
                          setNewEventDescription("");
                          setNewEventTime("");
                        }}
                        className="border-sage/30 text-sage hover:bg-sage/10"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {scheduleEvents.isLoading ? (
                  <div className="text-center py-8 text-soft-charcoal/60">Loading your schedule...</div>
                ) : scheduleEvents.data && scheduleEvents.data.length > 0 ? (
                  scheduleEvents.data.map((event) => (
                    <div key={event.id} className="group flex items-center space-x-4 p-4 rounded-2xl bg-light-gray hover:bg-sage/5 transition-colors">
                      {editingEvent === event.id ? (
                        <>
                          <Input
                            type="time"
                            value={editEventTime}
                            onChange={(e) => setEditEventTime(e.target.value)}
                            className="w-24 text-sm border-sage/30"
                          />
                          <div className="flex-1 space-y-2">
                            <Input
                              value={editEventTitle}
                              onChange={(e) => setEditEventTitle(e.target.value)}
                              className="font-medium border-sage/30"
                            />
                            <Input
                              value={editEventDescription}
                              onChange={(e) => setEditEventDescription(e.target.value)}
                              placeholder="Description (optional)"
                              className="text-sm border-sage/30"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <Button size="sm" onClick={handleSaveEvent} className="bg-sage text-white">
                              <Save className="w-3 h-3" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => {
                                setEditingEvent(null);
                                setEditEventTitle("");
                                setEditEventDescription("");
                                setEditEventTime("");
                              }}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-sm font-medium text-soft-charcoal w-20">
                            {event.time}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-soft-charcoal">{event.title}</div>
                            {event.description && (
                              <div className="text-sm text-soft-charcoal/80">{event.description}</div>
                            )}
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button size="sm" variant="ghost" onClick={() => handleEditEvent(event.id)}>
                              <Edit2 className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => handleDeleteEvent(event.id)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                          <div className="w-3 h-3 rounded-full bg-sage"></div>
                        </>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-soft-charcoal/60">
                    No events scheduled for today. Click "Add Event" to get started! ✨
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Tasks Section - Editable */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-semibold text-foreground dark:text-white">To-Do List</h3>
                <Button 
                  onClick={handleAddTask}
                  className="bg-pink-soft/20 text-pink-soft px-4 py-2 rounded-full text-sm font-medium hover:bg-pink-soft/30 transition-colors"
                  disabled={!newTaskTitle.trim()}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Task
                </Button>
              </div>

              {/* Add Task Input */}
              <div className="mb-6">
                <Input
                  placeholder="Add a new task..."
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleAddTask()}
                  className="border-pink-soft/30"
                />
              </div>

              <div className="space-y-3">
                {tasks.isLoading ? (
                  <div className="text-center py-8 text-soft-charcoal/60">Loading your tasks...</div>
                ) : tasks.data && tasks.data.length > 0 ? (
                  tasks.data.map((task) => (
                    <div key={task.id} className="group flex items-center space-x-4 p-4 rounded-2xl bg-light-gray hover:bg-pink-soft/5 transition-colors">
                      <Checkbox 
                        checked={task.completed}
                        onCheckedChange={(checked) => 
                          toggleTask.mutate({ id: task.id, completed: !!checked })
                        }
                        className="data-[state=checked]:bg-pink-soft data-[state=checked]:border-pink-soft"
                      />
                      
                      {editingTask === task.id ? (
                        <div className="flex-1 flex items-center gap-2">
                          <Input
                            value={editTaskTitle}
                            onChange={(e) => setEditTaskTitle(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSaveTask()}
                            className="flex-1 border-pink-soft/30"
                          />
                          <Button size="sm" onClick={handleSaveTask} className="bg-pink-soft text-white">
                            <Save className="w-3 h-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => {
                              setEditingTask(null);
                              setEditTaskTitle("");
                            }}
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <div className={`flex-1 ${task.completed ? 'line-through text-soft-charcoal/60' : 'text-soft-charcoal'}`}>
                            {task.title}
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button size="sm" variant="ghost" onClick={() => handleEditTask(task.id)}>
                              <Edit2 className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => handleDeleteTask(task.id)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-soft-charcoal/60">
                    No tasks yet. Add your first task above! ✨
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Wellness Reflection */}
          <Card className="bg-warm-white rounded-3xl shadow-sm border border-sage/10">
            <CardContent className="p-8">
              <h3 className="text-xl font-semibold text-soft-charcoal mb-6">Wellness Check-In</h3>
              <div className="space-y-4">
                <div className="p-4 bg-sage/10 rounded-2xl">
                  <h4 className="font-medium text-soft-charcoal mb-2">How are you feeling right now?</h4>
                  <p className="text-sm text-soft-charcoal/80">Take a moment to acknowledge your current state - physically, mentally, and emotionally.</p>
                </div>
                <div className="p-4 bg-sky-custom/10 rounded-2xl">
                  <h4 className="font-medium text-soft-charcoal mb-2">What does your body need today?</h4>
                  <p className="text-sm text-soft-charcoal/80">Movement, rest, nourishment, or something else?</p>
                </div>
                <div className="p-4 bg-pink-soft/10 rounded-2xl">
                  <h4 className="font-medium text-soft-charcoal mb-2">One thing you're grateful for:</h4>
                  <p className="text-sm text-soft-charcoal/80">Even small moments of appreciation can shift your day.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Trackers & Wellness */}
        <div className="space-y-8">
          {/* Pomodoro Timer */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground dark:text-white mb-4">Focus Timer</h3>
              <div className="text-center mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-sky-custom to-sky-light rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-lg">{formatTimer(timerTime)}</span>
                </div>
                <div className="text-sm text-soft-charcoal/80">Study Session</div>
              </div>
              <div className="flex justify-center space-x-3">
                <Button
                  onClick={toggleTimer}
                  className="bg-sky-custom text-white px-4 py-2 rounded-full text-sm font-medium hover:bg-sky-light transition-colors"
                >
                  {isTimerRunning ? <Pause /> : <Play className="w-4 h-4 mr-1" />}
                  {isTimerRunning ? "Pause" : "Start"}
                </Button>
                <Button 
                  onClick={resetTimer}
                  variant="outline"
                  className="bg-sage/20 text-sage px-4 py-2 rounded-full text-sm font-medium hover:bg-sage/30 transition-colors"
                >
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Water Tracker */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground dark:text-white mb-4">Water Intake</h3>
              <div className="flex justify-center mb-4">
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: waterGoal }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => handleWellnessUpdate("water", i + 1)}
                      className={`w-8 h-8 rounded-full transition-colors hover:scale-110 ${
                        i < currentWater 
                          ? 'bg-sky-custom' 
                          : i === currentWater 
                            ? 'bg-sky-custom/30 border-2 border-sky-custom border-dashed' 
                            : 'bg-sage/20 hover:bg-sky-custom/20'
                      }`}
                    />
                  ))}
                </div>
              </div>
              <div className="text-center text-sm text-soft-charcoal/80">{currentWater} out of {waterGoal} glasses today</div>
            </CardContent>
          </Card>

          {/* Exercise Tracker */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground dark:text-white mb-4">Exercise</h3>
              <div className="space-y-3 mb-4">
                <div className="w-full bg-pink-soft/20 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-pink-soft to-lavender h-2 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min((currentExercise / exerciseGoal) * 100, 100)}%` }}
                  ></div>
                </div>
                <div className="text-center text-sm text-soft-charcoal/80">{currentExercise}/{exerciseGoal} minutes goal</div>
              </div>
              <div className="flex gap-2">
                <Button 
                  onClick={() => setWellnessEditing(wellnessEditing === "exerciseGoal" ? null : "exerciseGoal")}
                  variant="outline"
                  className="flex-1 border-pink-soft/30 text-pink-soft hover:bg-pink-soft/10"
                >
                  Set Goal
                </Button>
                <Button 
                  onClick={() => setWellnessEditing(wellnessEditing === "exercise" ? null : "exercise")}
                  className="flex-1 bg-pink-soft/20 text-pink-soft hover:bg-pink-soft/30 transition-colors"
                >
                  {currentExercise > 0 ? "Update" : "Log"} Activity
                </Button>
              </div>
              
              {/* Exercise Goal Editor */}
              {wellnessEditing === "exerciseGoal" && (
                <div className="mt-3 p-3 bg-pink-soft/10 rounded-xl border border-pink-soft/20">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-soft-charcoal">Daily goal:</span>
                    <Input
                      type="number"
                      value={exerciseGoal}
                      onChange={(e) => {
                        const newValue = parseInt(e.target.value) || 45;
                        handleWellnessUpdate("exerciseGoal", newValue);
                      }}
                      onBlur={() => setWellnessEditing(null)}
                      className="w-20 text-sm border-pink-soft/30"
                      min="5"
                      max="300"
                      autoFocus
                    />
                    <span className="text-sm text-soft-charcoal">minutes</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Sleep Tracker - Editable */}
          <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground dark:text-white mb-4">Sleep Tracking</h3>
              <div className="text-center mb-4">
                <div className="text-2xl font-bold text-lavender">{currentSleep}h</div>
                <div className="text-sm text-soft-charcoal/80">Sleep goal</div>
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-soft-charcoal/80">Bedtime:</span>
                  {wellnessEditing === "bedtime" ? (
                    <div className="flex items-center gap-2">
                      <Input
                        type="time"
                        value={bedtime?.replace(/[AP]M/, '') || "22:00"}
                        onChange={(e) => {
                          const time = e.target.value;
                          const [hours, minutes] = time.split(':');
                          const hour12 = parseInt(hours) > 12 ? parseInt(hours) - 12 : parseInt(hours);
                          const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
                          const formatted = `${hour12}:${minutes} ${ampm}`;
                          handleWellnessUpdate("bedtime", formatted);
                        }}
                        className="w-20 text-xs border-lavender/30"
                      />
                      <Button size="sm" variant="ghost" onClick={() => setWellnessEditing(null)}>
                        <Save className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setWellnessEditing("bedtime")}
                      className="text-soft-charcoal hover:text-lavender transition-colors"
                    >
                      {bedtime} <Edit2 className="w-3 h-3 inline ml-1" />
                    </button>
                  )}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-soft-charcoal/80">Wake up:</span>
                  {wellnessEditing === "wakeTime" ? (
                    <div className="flex items-center gap-2">
                      <Input
                        type="time"
                        value={wakeTime?.replace(/[AP]M/, '') || "07:00"}
                        onChange={(e) => {
                          const time = e.target.value;
                          const [hours, minutes] = time.split(':');
                          const hour12 = parseInt(hours) > 12 ? parseInt(hours) - 12 : parseInt(hours);
                          const ampm = parseInt(hours) >= 12 ? 'PM' : 'AM';
                          const formatted = `${hour12}:${minutes} ${ampm}`;
                          handleWellnessUpdate("wakeTime", formatted);
                        }}
                        className="w-20 text-xs border-lavender/30"
                      />
                      <Button size="sm" variant="ghost" onClick={() => setWellnessEditing(null)}>
                        <Save className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setWellnessEditing("wakeTime")}
                      className="text-soft-charcoal hover:text-lavender transition-colors"
                    >
                      {wakeTime} <Edit2 className="w-3 h-3 inline ml-1" />
                    </button>
                  )}
                </div>
                <div className="flex justify-between">
                  <span className="text-soft-charcoal/80">Water Goal:</span>
                  {wellnessEditing === "waterGoal" ? (
                    <div className="flex items-center gap-2">
                      <Input
                        type="number"
                        value={waterGoal}
                        onChange={(e) => {
                          const newValue = parseInt(e.target.value) || 8;
                          handleWellnessUpdate("waterGoal", newValue);
                        }}
                        onBlur={() => setWellnessEditing(null)}
                        className="w-16 text-xs border-lavender/30"
                        min="1"
                        max="20"
                        autoFocus
                      />
                      <Button size="sm" variant="ghost" onClick={() => setWellnessEditing(null)}>
                        <Save className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => setWellnessEditing("waterGoal")}
                      className="text-soft-charcoal hover:text-lavender transition-colors"
                    >
                      {waterGoal} glasses <Edit2 className="w-3 h-3 inline ml-1" />
                    </button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Daily Affirmation */}
          <Card className="bg-gradient-to-br from-lavender/20 to-pink-soft/20 dark:from-lavender/30 dark:to-pink-soft/30 dark:bg-gray-800 rounded-3xl border border-lavender/30 dark:border-lavender/50">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-foreground dark:text-white mb-4">Today's Affirmation</h3>
              <p className="text-foreground dark:text-white text-center italic mb-4">
                "I am capable of handling whatever today brings with grace and confidence."
              </p>
              <Button 
                onClick={() => {
                  saveFavoriteQuote.mutate({
                    quote: "I am capable of handling whatever today brings with grace and confidence.",
                    source: "Daily Affirmation"
                  });
                }}
                disabled={saveFavoriteQuote.isPending}
                className="w-full bg-lavender/30 text-lavender py-2 rounded-full text-sm font-medium hover:bg-lavender/40 transition-colors"
              >
                <Heart className="w-4 h-4 mr-2" />
                Save to Favorites
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-sky-custom/10 to-mint/10 rounded-3xl border border-sky-custom/20 inline-block">
          <CardContent className="p-6">
            <p className="text-soft-charcoal/80 italic text-sm">
              {getDailyQuote()}
            </p>
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
};

export default PlannerPage;
