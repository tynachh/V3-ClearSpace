import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, X, Edit3 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ThoughtBubble } from "@shared/schema";

const QuickBubblesPage = () => {
  const [newBubbleContent, setNewBubbleContent] = useState("");
  const [selectedPriority, setSelectedPriority] = useState<"high" | "medium" | "low">("medium");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingContent, setEditingContent] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const bubbleColors = [
    { name: "sage", bg: "hsl(163, 55%, 68%)", light: "hsl(163, 55%, 85%)" },
    { name: "pink-soft", bg: "hsl(326, 78%, 83%)", light: "hsl(326, 78%, 90%)" },
    { name: "lavender", bg: "hsl(280, 90%, 86%)", light: "hsl(280, 90%, 92%)" },
    { name: "mint", bg: "hsl(163, 78%, 85%)", light: "hsl(163, 78%, 92%)" },
    { name: "sky-custom", bg: "hsl(195, 100%, 51%)", light: "hsl(195, 100%, 75%)" },
    { name: "purple", bg: "hsl(280, 67%, 75%)", light: "hsl(280, 67%, 88%)" },
    { name: "teal", bg: "hsl(178, 54%, 70%)", light: "hsl(178, 54%, 85%)" },
    { name: "rose", bg: "hsl(330, 70%, 80%)", light: "hsl(330, 70%, 90%)" },
    { name: "yellow", bg: "hsl(48, 89%, 76%)", light: "hsl(48, 89%, 88%)" },
    { name: "orange", bg: "hsl(25, 85%, 75%)", light: "hsl(25, 85%, 88%)" },
    { name: "cyan", bg: "hsl(188, 78%, 72%)", light: "hsl(188, 78%, 86%)" },
    { name: "indigo", bg: "hsl(239, 84%, 80%)", light: "hsl(239, 84%, 90%)" },
    { name: "coral", bg: "hsl(16, 85%, 78%)", light: "hsl(16, 85%, 88%)" },
    { name: "peach", bg: "hsl(28, 75%, 80%)", light: "hsl(28, 75%, 90%)" },
    { name: "lime", bg: "hsl(75, 70%, 75%)", light: "hsl(75, 70%, 87%)" },
    { name: "aqua", bg: "hsl(180, 85%, 70%)", light: "hsl(180, 85%, 85%)" },
    { name: "magenta", bg: "hsl(300, 75%, 80%)", light: "hsl(300, 75%, 90%)" },
    { name: "gold", bg: "hsl(50, 80%, 75%)", light: "hsl(50, 80%, 88%)" }
  ];

  // Daily motivational quotes
  const dailyQuotes = [
    "Every small step forward is progress worth celebrating ✨",
    "Your thoughts are just thoughts - you get to choose which ones to believe 💜",
    "Today is a fresh start, and you've got this 🌱",
    "Remember: it's okay to not be okay sometimes 🤗",
    "You're braver than you believe and stronger than you feel 💪"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  const { data: thoughtBubbles = [], isLoading } = useQuery<ThoughtBubble[]>({
    queryKey: ["/api/thought-bubbles"],
  });

  const createBubble = useMutation({
    mutationFn: async ({ content, priority }: { content: string; priority: string }) => {
      const randomColor = bubbleColors[Math.floor(Math.random() * bubbleColors.length)];
      return apiRequest("POST", "/api/thought-bubbles", { content, color: randomColor.name, priority });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/thought-bubbles"] });
      setNewBubbleContent("");
      toast({
        title: "Bubble created!",
        description: "Your thought has been saved.",
      });
    },
    onError: (error) => {
      console.error("Error creating bubble:", error);
      toast({
        title: "Oops!",
        description: "Couldn't create bubble. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateBubble = useMutation({
    mutationFn: async ({ id, content }: { id: number; content: string }) => {
      return apiRequest("PATCH", `/api/thought-bubbles/${id}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/thought-bubbles"] });
      setEditingId(null);
      setEditingContent("");
      toast({
        title: "Bubble updated!",
        description: "Your thought has been saved.",
      });
    },
    onError: (error) => {
      console.error("Error updating bubble:", error);
      toast({
        title: "Oops!",
        description: "Couldn't update bubble. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteBubble = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/thought-bubbles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/thought-bubbles"] });
      toast({
        title: "Bubble deleted!",
        description: "Your thought has been removed.",
      });
    },
    onError: (error) => {
      console.error("Error deleting bubble:", error);
      toast({
        title: "Oops!",
        description: "Couldn't delete bubble. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateBubble = () => {
    if (newBubbleContent.trim()) {
      try {
        createBubble.mutate({ content: newBubbleContent.trim(), priority: selectedPriority });
      } catch (error) {
        console.error("Error in handleCreateBubble:", error);
      }
    }
  };

  const handleEditBubble = (bubble: ThoughtBubble) => {
    setEditingId(bubble.id);
    setEditingContent(bubble.content);
  };

  const handleSaveEdit = () => {
    if (editingId && editingContent.trim()) {
      updateBubble.mutate({ id: editingId, content: editingContent.trim() });
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditingContent("");
  };

  const getColorForBubble = (colorName: string) => {
    return bubbleColors.find(c => c.name === colorName) || bubbleColors[0];
  };

  const getBubbleSize = (priority: string) => {
    switch (priority) {
      case "high": return "w-40 h-40 text-sm";
      case "medium": return "w-32 h-32 text-xs";
      case "low": return "w-24 h-24 text-xs";
      default: return "w-32 h-32 text-xs";
    }
  };

  const getBubblePosition = (index: number) => {
    const positions = [
      "top-16 left-12", "top-28 right-16", "top-44 left-1/4", "top-20 right-1/3",
      "bottom-20 left-20", "bottom-32 right-12", "bottom-16 left-1/3", "bottom-28 right-1/4",
      "top-52 left-1/2", "top-36 right-20", "bottom-36 left-1/2", "top-24 left-2/3",
      "bottom-20 right-1/3", "top-32 right-1/2", "bottom-24 left-1/5", "top-48 right-1/5",
      "bottom-40 left-2/3", "top-60 left-16", "bottom-44 right-24", "top-40 left-3/4"
    ];
    return positions[index % positions.length];
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 relative">
      {/* Floating decorative elements - edge positioned */}
      <div className="absolute top-4 left-4 w-12 h-12 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.3}}></div>
      <div className="absolute top-16 right-4 w-8 h-8 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.4, animationDelay: '1s'}}></div>
      <div className="absolute bottom-4 left-4 w-16 h-16 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.35, animationDelay: '2s'}}></div>
      <div className="absolute top-32 right-8 w-10 h-10 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.3, animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-16 right-4 w-14 h-14 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 55%, 68%)', opacity: 0.4, animationDelay: '1.5s'}}></div>

      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-soft-charcoal mb-4">Quick Bubbles</h1>
        <p className="text-lg text-soft-charcoal/80">Capture your thoughts, ideas, and reminders in colorful bubbles</p>
      </div>

      {/* Add New Bubble */}
      <Card className="bg-warm-white rounded-3xl shadow-sm border border-sage/10 mb-8">
        <CardContent className="p-6">
          <div className="space-y-4">
            <input
              type="text"
              placeholder="What's on your mind? Jot it down quickly..."
              value={newBubbleContent}
              onChange={(e) => setNewBubbleContent(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateBubble()}
              className="w-full p-3 border border-sage/20 rounded-2xl focus:outline-none focus:border-sage transition-colors text-soft-charcoal"
            />
            
            {/* Priority Buttons */}
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <Button
                  variant={selectedPriority === "high" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedPriority("high")}
                  className={`rounded-full ${selectedPriority === "high" ? "bg-red-500 text-white" : "border-red-500 text-red-500"}`}
                >
                  High Priority
                </Button>
                <Button
                  variant={selectedPriority === "medium" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedPriority("medium")}
                  className={`rounded-full ${selectedPriority === "medium" ? "bg-orange-500 text-white" : "border-orange-500 text-orange-500"}`}
                >
                  Medium Priority
                </Button>
                <Button
                  variant={selectedPriority === "low" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedPriority("low")}
                  className={`rounded-full ${selectedPriority === "low" ? "bg-green-500 text-white" : "border-green-500 text-green-500"}`}
                >
                  Low Priority
                </Button>
              </div>
              
              <Button
                onClick={handleCreateBubble}
                disabled={!newBubbleContent.trim() || createBubble.isPending}
                className="bg-gradient-to-r from-sage to-sage-dark text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all duration-200"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Bubble
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Thought Bubbles Grid */}
      {isLoading ? (
        <div className="text-center py-12 text-soft-charcoal/60">Loading your bubbles...</div>
      ) : thoughtBubbles.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-soft-charcoal/60 mb-4">No bubbles yet! Add your first thought above.</div>
          <div className="text-sm text-soft-charcoal/50">Perfect for quick notes, reminders, or random thoughts</div>
        </div>
      ) : (
        <div className="relative min-h-[600px] mb-8">
          {thoughtBubbles.map((bubble, index) => {
            const colorInfo = getColorForBubble(bubble.color);
            const bubbleSize = getBubbleSize(bubble.priority || "medium");
            const position = getBubblePosition(index);
            return (
              <div
                key={bubble.id}
                className={`group absolute rounded-full border shadow-lg transition-all duration-200 hover:shadow-xl cursor-move flex items-center justify-center animate-float ${bubbleSize} ${position}`}
                style={{
                  backgroundColor: colorInfo.light,
                  borderColor: colorInfo.bg,
                  borderWidth: '3px',
                  animationDelay: `${index * 0.3}s`
                }}
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData("text/plain", bubble.id.toString());
                }}
              >
                <div className="absolute inset-2 flex flex-col items-center justify-center text-center overflow-hidden">
                  {editingId === bubble.id ? (
                    <div className="w-full h-full flex flex-col items-center justify-center p-1">
                      <textarea
                        value={editingContent}
                        onChange={(e) => setEditingContent(e.target.value)}
                        className="w-full h-12 p-1 border border-sage/20 rounded-lg resize-none focus:outline-none focus:border-sage transition-colors text-soft-charcoal bg-white/80 text-xs"
                        autoFocus
                      />
                      <div className="flex gap-1 mt-1">
                        <button
                          onClick={handleSaveEdit}
                          className="bg-sage text-white px-2 py-1 rounded-full text-xs hover:bg-sage-dark"
                        >
                          ✓
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="bg-gray-200 text-gray-600 px-2 py-1 rounded-full text-xs hover:bg-gray-300"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="text-soft-charcoal text-center leading-tight break-words px-1">
                        {bubble.content.length > 50 ? `${bubble.content.substring(0, 50)}...` : bubble.content}
                      </p>
                      <div className="absolute top-1 right-1 flex gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleEditBubble(bubble)}
                          className="w-4 h-4 bg-white/80 rounded-full flex items-center justify-center hover:bg-white"
                        >
                          <Edit3 className="w-2 h-2 text-gray-600" />
                        </button>
                        <button
                          onClick={() => deleteBubble.mutate(bubble.id)}
                          className="w-4 h-4 bg-white/80 rounded-full flex items-center justify-center hover:bg-white"
                        >
                          <X className="w-2 h-2 text-gray-600" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-sage/10 to-mint/10 rounded-3xl border border-sage/20 inline-block">
          <CardContent className="p-6">
            <p className="text-soft-charcoal/80 italic text-lg">
              "Your thoughts are temporary visitors - you get to choose which ones to believe 💙"
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuickBubblesPage;