import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Calendar, 
  Brain, 
  Leaf, 
  Scale, 
  Heart, 
  Bell,
  Play
} from "lucide-react";

const HomePage = () => {
  // Daily motivational quotes
  const dailyQuotes = [
    "Every small step forward is progress worth celebrating ✨",
    "Your thoughts are just thoughts - you get to choose which ones to believe 💜",
    "Today is a fresh start, and you've got this 🌱",
    "Remember: it's okay to not be okay sometimes 🤗",
    "You're braver than you believe and stronger than you feel 💪",
    "Growth happens outside your comfort zone 🌟",
    "Your mental health matters more than your grades 💙"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          {/* Floating decorative elements - Positioned to avoid overlap */}
          <div className="absolute top-4 left-4 w-12 h-12 rounded-full animate-float" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.4}}></div>
          <div className="absolute top-8 right-8 w-8 h-8 rounded-full animate-float" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.5, animationDelay: '1s'}}></div>
          <div className="absolute bottom-4 left-8 w-16 h-16 rounded-full animate-float" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.4, animationDelay: '2s'}}></div>
          <div className="absolute top-20 right-20 w-6 h-6 rounded-full animate-float" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.35, animationDelay: '0.5s'}}></div>
          <div className="absolute bottom-8 right-4 w-10 h-10 rounded-full animate-float" style={{backgroundColor: 'hsl(163, 55%, 68%)', opacity: 0.35, animationDelay: '1.5s'}}></div>
          <div className="absolute top-40 left-2 w-8 h-8 rounded-full animate-float" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.45, animationDelay: '2.5s'}}></div>
          <div className="absolute bottom-20 left-12 w-4 h-4 rounded-full animate-float" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.6, animationDelay: '3s'}}></div>
          <div className="absolute top-12 right-32 w-14 h-14 rounded-full animate-float" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.5, animationDelay: '0.8s'}}></div>
          {/* Small sparkly circles */}
          <div className="absolute top-32 left-6 w-3 h-3 rounded-full animate-sparkle" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.6, animationDelay: '1.2s'}}></div>
          <div className="absolute bottom-12 right-12 w-4 h-4 rounded-full animate-sparkle" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.7, animationDelay: '2.3s'}}></div>
          <div className="absolute top-24 left-20 w-2 h-2 rounded-full animate-sparkle" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.8, animationDelay: '0.7s'}}></div>
          
          <div className="relative z-10">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
              Find your <span className="text-sage">calm</span>.<br />
              Own your <span className="text-sky-custom">time</span>.<br />
              Be <span className="text-pink-soft">yourself</span>.
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
              ClearSpace is the all-in-one wellness and productivity website made for teens, by teens — designed to help you stay balanced, focused, and in control when life gets overwhelming.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/mood">
                <Button className="bg-gradient-to-r from-sage to-sage-dark text-white px-8 py-4 rounded-full font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                  Start Your Journey
                </Button>
              </Link>
              <Link href="/meditation">
                <Button variant="outline" className="bg-background text-foreground px-8 py-4 rounded-full font-medium border-2 border-sage/30 hover:border-sage hover:shadow-lg transition-all duration-200">
                  <Play className="w-4 h-4 mr-2" />
                  Quick Meditation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4 relative">
        {/* Additional floating circles for features section */}
        <div className="absolute top-10 left-20 w-6 h-6 bg-pink-soft/50 rounded-full animate-float" style={{animationDelay: '2.2s'}}></div>
        <div className="absolute top-40 right-28 w-8 h-8 bg-lavender/40 rounded-full animate-float" style={{animationDelay: '1.8s'}}></div>
        <div className="absolute bottom-20 left-32 w-12 h-12 bg-mint/45 rounded-full animate-float" style={{animationDelay: '2.8s'}}></div>
        
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-16">
            Everything you need to <span className="text-sage">thrive</span>
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Mood-Based Planner */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-soft to-lavender rounded-2xl flex items-center justify-center mb-6">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Mood-Based Planner</h3>
                <p className="text-muted-foreground leading-relaxed">Don't just plan your day—feel your day. We'll suggest a schedule that matches your energy and mindset.</p>
              </CardContent>
            </Card>

            {/* Brain Dump Journal */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-sage to-mint rounded-2xl flex items-center justify-center mb-6">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Brain Dump Journal</h3>
                <p className="text-muted-foreground leading-relaxed">Get it all out. A judgment-free zone to clear your head when you have a million tabs open in your mind.</p>
              </CardContent>
            </Card>

            {/* Guided Meditation */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-sky-custom to-sky-light rounded-2xl flex items-center justify-center mb-6">
                  <Leaf className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Guided Meditation</h3>
                <p className="text-muted-foreground leading-relaxed">Short, calming sessions for focus, anxiety, and better sleep. Ground yourself with soothing audio tracks.</p>
              </CardContent>
            </Card>

            {/* Life Balance Tracker */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-lavender to-pink-soft rounded-2xl flex items-center justify-center mb-6">
                  <Scale className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Life Balance Tracker</h3>
                <p className="text-muted-foreground leading-relaxed">Visually track how you're balancing academics, social life, rest, and personal growth.</p>
              </CardContent>
            </Card>

            {/* Daily Affirmations */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-mint to-sage-light rounded-2xl flex items-center justify-center mb-6">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Daily Affirmations</h3>
                <p className="text-muted-foreground leading-relaxed">Start each day with a quote that speaks to you. Stay inspired with encouraging reminders.</p>
              </CardContent>
            </Card>

            {/* Gentle Reminders */}
            <Card className="bg-card rounded-3xl shadow-sm hover:shadow-lg transition-all duration-300 border border-border">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-gradient-to-br from-pink-soft to-sage rounded-2xl flex items-center justify-center mb-6">
                  <Bell className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4">Gentle Reminders</h3>
                <p className="text-muted-foreground leading-relaxed">Set mindful, non-overwhelming alerts for self-care, assignments, or just to breathe and check in.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="bg-gradient-to-r from-sage/10 to-mint/10 dark:from-sage/15 dark:to-mint/15 rounded-3xl border border-sage/20 dark:border-sage/40">
            <CardContent className="p-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Because being a teen today is <span className="text-sage">a lot</span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                ClearSpace was built by students who get it — who know what it's like to feel burned out, behind, or like you're constantly on autopilot. This website isn't just about productivity — it's about peace.
              </p>
              <p className="text-xl font-medium text-foreground mb-8">
                Take a deep breath. Open ClearSpace. You've got this. ✨
              </p>
              <Link href="/mood">
                <Button className="bg-gradient-to-r from-sage to-sage-dark text-white px-10 py-4 rounded-full font-medium hover:shadow-lg transform hover:scale-105 transition-all duration-200">
                  Begin Your Journey
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Daily Quote */}
      <section className="pb-16 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="bg-gradient-to-r from-pink-soft/10 to-lavender/10 dark:from-pink-soft/15 dark:to-lavender/15 rounded-3xl border border-pink-soft/20 dark:border-pink-soft/40">
            <CardContent className="p-6">
              <p className="text-muted-foreground italic text-lg">
                {getDailyQuote()}
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
