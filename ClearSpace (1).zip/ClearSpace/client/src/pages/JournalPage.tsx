import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useJournal } from "@/hooks/useJournal";
import { format } from "date-fns";
import { ChevronDown, ChevronUp, Trash2 } from "lucide-react";

const journalPrompts = [
  {
    title: "Three things I'm grateful for today...",
    description: "Gratitude practice"
  },
  {
    title: "What's stressing me out right now...",
    description: "Stress release"
  },
  {
    title: "My biggest win this week was...",
    description: "Celebration"
  },
  {
    title: "I'm feeling confused about...",
    description: "Processing emotions"
  }
];

const JournalPage = () => {
  const [entry, setEntry] = useState("");
  const [title, setTitle] = useState("");
  const [showAllEntries, setShowAllEntries] = useState(false);
  const [expandedEntry, setExpandedEntry] = useState<number | null>(null);
  const { journalEntries, saveJournalEntry, deleteJournalEntry } = useJournal();

  // Daily motivational quotes
  const dailyQuotes = [
    "Your story matters - every word you write is valid",
    "Feelings are temporary visitors - let them flow through your pen", 
    "There's no wrong way to express yourself in these pages",
    "Your thoughts deserve space to breathe and be heard",
    "Writing is healing - be gentle with yourself today",
    "Every entry is a step toward understanding yourself better",
    "Your journal is your safe space - write freely"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  const handleSave = () => {
    if (entry.trim()) {
      saveJournalEntry.mutate({
        title: title.trim() || undefined,
        content: entry.trim(),
      });
      setEntry("");
      setTitle("");
    }
  };

  const wordCount = entry.trim().split(/\s+/).filter(word => word.length > 0).length;

  const usePrompt = (prompt: string) => {
    setEntry(prev => prev + (prev ? "\n\n" : "") + prompt + "\n");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 relative">
      {/* Floating decorative elements - edge positioned to avoid text */}
      <div className="absolute top-4 left-2 w-10 h-10 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 78%, 85%)', opacity: 0.4}}></div>
      <div className="absolute top-20 right-4 w-14 h-14 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(326, 78%, 83%)', opacity: 0.35, animationDelay: '1s'}}></div>
      <div className="absolute bottom-4 left-4 w-12 h-12 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(280, 90%, 86%)', opacity: 0.45, animationDelay: '2s'}}></div>
      <div className="absolute top-48 right-2 w-8 h-8 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(163, 55%, 68%)', opacity: 0.4, animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-16 right-4 w-16 h-16 rounded-full animate-float pointer-events-none" style={{backgroundColor: 'hsl(195, 100%, 51%)', opacity: 0.3, animationDelay: '1.5s'}}></div>
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground dark:text-white mb-4">Brain Dump Journal</h1>
        <p className="text-lg text-muted-foreground dark:text-gray-300">Get it all out. This is your judgment-free zone to clear your head.</p>
      </div>

      {/* Writing Area */}
      <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border mb-8">
        <CardContent className="p-6">
          <div className="border-b border-border pb-4 mb-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-foreground dark:text-white">Today's Entry</h2>
              <div className="text-sm text-muted-foreground dark:text-gray-300">{format(new Date(), "MMMM d, yyyy")}</div>
            </div>
          </div>
          
          <div className="space-y-4">
            <input
              type="text"
              placeholder="Entry title (optional)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-3 border border-border rounded-2xl focus:outline-none focus:border-sage transition-colors text-foreground dark:text-white bg-background dark:bg-gray-800"
            />
            
            <Textarea
              placeholder="What's on your mind? Don't worry about grammar, structure, or making sense. Just let it flow..."
              value={entry}
              onChange={(e) => setEntry(e.target.value)}
              className="w-full h-80 p-4 border border-border rounded-2xl resize-none focus:outline-none focus:border-sage transition-colors text-foreground dark:text-white bg-background dark:bg-gray-800"
            />
            
            <div className="flex justify-between items-center">
              <div className="text-sm text-muted-foreground dark:text-gray-300">Word count: {wordCount}</div>
              <Button 
                onClick={handleSave}
                disabled={!entry.trim() || saveJournalEntry.isPending}
                className="bg-gradient-to-r from-sage to-sage-dark text-white px-6 py-2 rounded-full font-medium hover:shadow-lg transition-all duration-200"
              >
                {saveJournalEntry.isPending ? "Saving..." : "Save Entry"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Journal Prompts */}
      <Card className="bg-gradient-to-br from-pink-soft/8 to-lavender/8 dark:from-pink-soft/15 dark:to-lavender/15 rounded-3xl border border-pink-soft/15 dark:border-pink-soft/30 mb-8 shadow-sm">
        <CardContent className="p-8">
          <div className="text-center mb-6">
            <h3 className="text-xl font-semibold text-foreground dark:text-white mb-2">✨ Need a spark of inspiration? ✨</h3>
            <p className="text-sm text-muted-foreground dark:text-gray-300">Click any prompt below to add it to your journal entry</p>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {journalPrompts.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                className="group text-left p-5 h-auto rounded-2xl border-2 border-pink-soft/20 dark:border-pink-soft/40 hover:border-pink-soft hover:shadow-md transition-all duration-200 bg-card dark:bg-gray-700 hover:bg-background dark:hover:bg-gray-600"
                onClick={() => usePrompt(prompt.title)}
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="font-semibold text-foreground dark:text-white group-hover:text-pink-soft transition-colors">
                      {prompt.title}
                    </div>
                    <div className="text-pink-soft/60 group-hover:text-pink-soft transition-colors text-sm">+</div>
                  </div>
                  <div className="text-sm text-muted-foreground dark:text-gray-300 leading-relaxed">
                    {prompt.description}
                  </div>
                </div>
              </Button>
            ))}
          </div>
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground dark:text-gray-400">💡 These prompts will be added to your current entry - you can edit them however you like!</p>
          </div>
        </CardContent>
      </Card>

      {/* Past Entries */}
      <Card className="bg-card dark:bg-gray-900 rounded-3xl shadow-sm border border-border">
        <CardContent className="p-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold text-foreground dark:text-white">Your Journal History</h3>
            {journalEntries.data && journalEntries.data.length > 3 && (
              <Button
                variant="ghost"
                onClick={() => setShowAllEntries(!showAllEntries)}
                className="text-sage hover:text-sage-dark"
              >
                {showAllEntries ? (
                  <>Show Less <ChevronUp className="ml-1 h-4 w-4" /></>
                ) : (
                  <>Show All ({journalEntries.data.length}) <ChevronDown className="ml-1 h-4 w-4" /></>
                )}
              </Button>
            )}
          </div>
          
          {journalEntries.isLoading ? (
            <div className="text-center py-8 text-soft-charcoal/60">Loading your entries...</div>
          ) : journalEntries.data && journalEntries.data.length > 0 ? (
            <div className="space-y-4">
              {(showAllEntries ? journalEntries.data : journalEntries.data.slice(0, 3)).map((entry) => (
                <div key={entry.id} className="p-5 bg-gradient-to-r from-sage/5 to-mint/5 rounded-2xl border border-sage/10 hover:border-sage/20 transition-colors cursor-pointer">
                  <div className="flex justify-between items-start mb-3">
                    <div className="space-y-2">
                      {entry.title && (
                        <div className="text-lg font-semibold text-soft-charcoal">{entry.title}</div>
                      )}
                      <div className="flex items-center gap-3 text-sm text-soft-charcoal/60">
                        <span>{format(new Date(entry.date), "MMMM d, yyyy")}</span>
                        <span>•</span>
                        <span>{Math.ceil(entry.content.length / 300)} min read</span>
                        <span>•</span>
                        <span>{entry.content.split(' ').length} words</span>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteJournalEntry.mutate(entry.id)}
                        className="text-red-500 hover:text-red-600 p-2"
                        title="Delete entry"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedEntry(expandedEntry === entry.id ? null : entry.id)}
                        className="text-sage hover:text-sage-dark p-2"
                      >
                        {expandedEntry === entry.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="text-soft-charcoal/80 text-sm leading-relaxed">
                    {expandedEntry === entry.id ? (
                      <div className="whitespace-pre-wrap">{entry.content}</div>
                    ) : (
                      <div className="line-clamp-3">
                        {entry.content.length > 180 
                          ? entry.content.substring(0, 180) + "..."
                          : entry.content
                        }
                      </div>
                    )}
                  </div>
                  
                  {expandedEntry !== entry.id && entry.content.length > 180 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedEntry(entry.id)}
                      className="mt-2 text-sage hover:text-sage-dark p-0 h-auto"
                    >
                      Read more
                    </Button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-soft-charcoal/60">
              No journal entries yet. Start writing your first entry above! ✨
            </div>
          )}
        </CardContent>
      </Card>

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-sage/5 via-mint/10 to-lavender/10 rounded-3xl border border-sage/20 shadow-lg max-w-2xl mx-auto">
          <CardContent className="p-8">
            <div className="mb-4">
              <div className="w-12 h-12 mx-auto bg-gradient-to-br from-sage to-mint rounded-full flex items-center justify-center mb-4">
                <span className="text-white text-xl">✨</span>
              </div>
              <h3 className="text-lg font-semibold text-soft-charcoal/90 mb-3">Daily Inspiration</h3>
            </div>
            <blockquote className="text-soft-charcoal/80 italic text-xl leading-relaxed font-medium mb-4">
              "{getDailyQuote()}"
            </blockquote>
            <div className="flex gap-2 justify-center">
              <Button
                variant="ghost"
                size="sm"
                className="text-sage hover:text-sage-dark hover:bg-sage/10"
                title="Add to favorites"
              >
                ♡ Save Quote
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default JournalPage;
