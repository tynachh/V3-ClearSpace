import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useBalance } from "@/hooks/useBalance";
import { useBalanceCalculations } from "@/hooks/useBalanceCalculations";
import { useFavoriteQuotes } from "@/hooks/useFavoriteQuotes";
import { GraduationCap, Users, Heart, Dumbbell, Star } from "lucide-react";

const BalancePage = () => {
  const { balanceEntries, saveBalanceEntry } = useBalance();
  const { balanceScore, weeklyProgress, insights } = useBalanceCalculations();
  const { saveFavoriteQuote } = useFavoriteQuotes();

  // Daily motivational quotes
  const dailyQuotes = [
    "Balance isn't perfection - it's progress and self-compassion",
    "Small steps in all areas create lasting life harmony",
    "Your worth isn't measured by productivity alone",
    "It's okay to prioritize different areas on different days",
    "Balance looks different for everyone - find what works for you",
    "Self-care isn't selfish - it's necessary for everything else",
    "You're managing more than you realize - give yourself credit"
  ];

  const getDailyQuote = () => {
    const day = new Date().getDate();
    return dailyQuotes[day % dailyQuotes.length];
  };

  const currentQuote = getDailyQuote();

  const handleSaveQuote = () => {
    saveFavoriteQuote.mutate({
      quote: currentQuote,
      source: "Daily Balance Quote"
    });
  };

  const categories = [
    {
      id: "academic",
      name: "Academic",
      score: balanceScore.categoryScores.academic,
      icon: GraduationCap,
      color: "from-sky-custom to-sky-light",
      description: balanceScore.categoryScores.academic >= 7 ? "You're doing great with your studies! Keep up the momentum." : 
                   balanceScore.categoryScores.academic >= 5 ? "Your academic progress is steady. Consider breaking big tasks into smaller steps." :
                   "Focus on small, manageable study goals each day."
    },
    {
      id: "social", 
      name: "Social",
      score: balanceScore.categoryScores.social,
      icon: Users,
      color: "from-pink-soft to-lavender",
      description: balanceScore.categoryScores.social >= 7 ? "Your social connections are thriving!" :
                   balanceScore.categoryScores.social >= 5 ? "Consider reaching out to friends or planning a fun activity." :
                   "Try to connect with one person today, even briefly."
    },
    {
      id: "selfCare",
      name: "Self-Care", 
      score: balanceScore.categoryScores.selfCare,
      icon: Heart,
      color: "from-sage to-mint",
      description: balanceScore.categoryScores.selfCare >= 7 ? "You're taking great care of yourself!" :
                   balanceScore.categoryScores.selfCare >= 5 ? "Time to prioritize yourself! Schedule some me-time today." :
                   "Self-care is essential. Start with just 10 minutes for yourself."
    },
    {
      id: "physical",
      name: "Physical",
      score: balanceScore.categoryScores.physical,
      icon: Dumbbell,
      color: "from-lavender to-pink-soft", 
      description: balanceScore.categoryScores.physical >= 7 ? "Nice work staying active! Keep moving your body." :
                   balanceScore.categoryScores.physical >= 5 ? "Add a little more movement to your day when you can." :
                   "Every step counts! Try a 5-minute walk or stretch."
    }
  ];

  const handleSaveBalance = () => {
    const balanceData = {
      academic: 8,
      social: 6, 
      selfCare: 5,
      physical: 7
    };
    saveBalanceEntry.mutate(balanceData);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 relative">
      {/* Enhanced Floating decorative elements - more bubbles */}
      <div className="absolute top-4 left-4 w-14 h-14 bg-sage/30 rounded-full animate-float pointer-events-none"></div>
      <div className="absolute top-16 right-4 w-10 h-10 bg-pink-soft/40 rounded-full animate-float pointer-events-none" style={{animationDelay: '1s'}}></div>
      <div className="absolute bottom-4 left-4 w-16 h-16 bg-lavender/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '2s'}}></div>
      <div className="absolute top-32 right-8 w-8 h-8 bg-mint/45 rounded-full animate-float pointer-events-none" style={{animationDelay: '0.5s'}}></div>
      <div className="absolute bottom-16 right-4 w-12 h-12 bg-sky-custom/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '1.5s'}}></div>
      
      {/* Additional colorful bubbles */}
      <div className="absolute top-8 left-2 w-6 h-6 bg-purple-400/30 rounded-full animate-float pointer-events-none" style={{animationDelay: '3s'}}></div>
      <div className="absolute top-48 right-2 w-18 h-18 bg-teal-300/25 rounded-full animate-float pointer-events-none" style={{animationDelay: '4s'}}></div>
      <div className="absolute bottom-32 left-2 w-12 h-12 bg-yellow-300/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '2.5s'}}></div>
      <div className="absolute top-24 left-8 w-4 h-4 bg-rose-300/40 rounded-full animate-float pointer-events-none" style={{animationDelay: '1.8s'}}></div>
      <div className="absolute bottom-48 right-8 w-8 h-8 bg-indigo-300/35 rounded-full animate-float pointer-events-none" style={{animationDelay: '3.2s'}}></div>
      <div className="absolute top-64 right-16 w-10 h-10 bg-emerald-300/25 rounded-full animate-float pointer-events-none" style={{animationDelay: '4.5s'}}></div>
      <div className="absolute bottom-8 left-16 w-14 h-14 bg-amber-300/30 rounded-full animate-float pointer-events-none" style={{animationDelay: '2.8s'}}></div>
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-foreground dark:text-white mb-4">Life Balance Tracker</h1>
        <p className="text-lg text-muted-foreground dark:text-gray-300">Visually track how you're balancing all areas of your life</p>
      </div>

      {/* Balance Wheel */}
      <Card className="bg-card dark:bg-gray-800 rounded-3xl shadow-sm border border-border mb-8">
        <CardContent className="p-8">
          <h2 className="text-xl font-semibold text-foreground dark:text-white mb-6 text-center">Your Life Balance Wheel</h2>
          <div className="flex justify-center mb-8">
            <div className="relative w-80 h-80">
              <div className="w-full h-full bg-gradient-to-br from-sage/10 to-mint/10 dark:from-sage/20 dark:to-mint/20 rounded-full border-4 border-sage/20 dark:border-sage/40 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl mb-2">⚖️</div>
                  <div className="text-lg font-semibold text-foreground dark:text-white">Balance Score</div>
                  <div className="text-2xl font-bold text-sage">{balanceScore.overallScore}/10</div>
                </div>
              </div>
            </div>
          </div>
          <p className="text-center text-muted-foreground dark:text-gray-300">
            {balanceScore.overallScore >= 7 ? "Your overall balance is excellent! Keep up the great work." :
             balanceScore.overallScore >= 5 ? "Your balance is developing well. Small adjustments can make a big difference." :
             "Focus on one area at a time. Every small step toward balance matters."}
          </p>
        </CardContent>
      </Card>

      {/* Balance Categories */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {categories.map((category) => {
          const IconComponent = category.icon;
          return (
            <Card key={category.id} className="bg-card dark:bg-gray-800 rounded-2xl shadow-sm border border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 bg-gradient-to-br ${category.color} rounded-2xl flex items-center justify-center`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <h3 className="font-semibold text-foreground">{category.name}</h3>
                  </div>
                  <div className="text-sm font-medium text-foreground">{category.score}/10</div>
                </div>
                <div className="w-full bg-sage/20 dark:bg-sage/30 rounded-full h-2 mb-4">
                  <div 
                    className={`bg-gradient-to-r ${category.color} h-2 rounded-full`}
                    style={{ width: `${category.score * 10}%` }}
                  ></div>
                </div>
                <p className="text-sm text-muted-foreground">{category.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Weekly Check-in */}
      <Card className="bg-gradient-to-r from-sage/10 to-mint/10 rounded-3xl border border-sage/20 mb-8">
        <CardContent className="p-8">
          <h3 className="text-xl font-semibold text-foreground dark:text-white mb-6">Weekly Check-in</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-medium text-soft-charcoal mb-4">How are you feeling about balance this week?</h4>
              <div className="space-y-3">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input type="radio" name="balance-feeling" className="text-sage focus:ring-sage" />
                  <span className="text-soft-charcoal">Really balanced and in control</span>
                </label>
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input type="radio" name="balance-feeling" className="text-sage focus:ring-sage" />
                  <span className="text-soft-charcoal">Mostly good, some areas need attention</span>
                </label>
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input type="radio" name="balance-feeling" className="text-sage focus:ring-sage" />
                  <span className="text-soft-charcoal">Struggling to balance everything</span>
                </label>
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input type="radio" name="balance-feeling" className="text-sage focus:ring-sage" />
                  <span className="text-soft-charcoal">Feeling overwhelmed and off-track</span>
                </label>
              </div>
            </div>
            <div>
              <h4 className="font-medium text-soft-charcoal mb-4">What area needs the most love this week?</h4>
              <select className="w-full p-3 border border-sage/20 rounded-2xl focus:outline-none focus:border-sage text-soft-charcoal mb-4">
                <option>Select an area...</option>
                <option>Academic work</option>
                <option>Social connections</option>
                <option>Self-care and rest</option>
                <option>Physical health</option>
                <option>Family time</option>
                <option>Personal hobbies</option>
              </select>
              <Button 
                onClick={handleSaveBalance}
                disabled={saveBalanceEntry.isPending}
                className="bg-gradient-to-r from-sage to-sage-dark text-white px-6 py-3 rounded-full font-medium hover:shadow-lg transition-all duration-200"
              >
                {saveBalanceEntry.isPending ? "Updating..." : "Update Balance Plan"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Balance History */}
      <Card className="bg-warm-white rounded-3xl shadow-sm border border-sage/10">
        <CardContent className="p-8">
          <h3 className="text-xl font-semibold text-soft-charcoal mb-6">Balance Trends</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-medium text-soft-charcoal mb-4">This Month's Progress</h4>
              <div className="space-y-3">
                {weeklyProgress.map((week, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-sm text-soft-charcoal">{week.week}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-20 bg-sage/20 rounded-full h-2">
                        <div 
                          className="bg-sage h-2 rounded-full"
                          style={{ width: `${(week.score / 10) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-soft-charcoal">{week.score}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-medium text-soft-charcoal mb-4">Insights & Suggestions</h4>
              <div className="space-y-3">
                {insights.map((insight, index) => (
                  <div key={index} className={`p-3 rounded-2xl border-l-4 ${insight.color}`}>
                    <p className="text-sm text-soft-charcoal">{insight.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Quote */}
      <div className="text-center mt-16 mb-8">
        <Card className="bg-gradient-to-r from-sage/5 via-mint/10 to-lavender/10 rounded-3xl border border-sage/20 shadow-lg max-w-2xl mx-auto">
          <CardContent className="p-8">
            <div className="mb-4">
              <div className="w-12 h-12 mx-auto bg-gradient-to-br from-sage to-mint rounded-full flex items-center justify-center mb-4">
                <span className="text-white text-xl">⚖️</span>
              </div>
              <h3 className="text-lg font-semibold text-soft-charcoal/90 mb-3">Balance Wisdom</h3>
            </div>
            <blockquote className="text-soft-charcoal/80 italic text-sm leading-relaxed font-medium mb-4">
              "{currentQuote}"
            </blockquote>
            <div className="flex gap-2 justify-center">
              <Button
                onClick={handleSaveQuote}
                disabled={saveFavoriteQuote.isPending}
                variant="ghost"
                size="sm"
                className="text-sage hover:text-sage-dark hover:bg-sage/10"
                title="Add to favorites"
              >
                <Star className="w-3 h-3 mr-1" />
                Save Quote
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BalancePage;
