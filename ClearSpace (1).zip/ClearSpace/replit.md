# ClearSpace - Teen Wellness & Productivity App

## Overview

ClearSpace is a comprehensive wellness and productivity application designed specifically for teenagers. It combines mental health tracking, journaling, meditation, life balance monitoring, and task planning in a cohesive, youth-friendly interface. The application uses a modern tech stack with React frontend and Express backend, featuring a soothing design with custom color themes focused on calming sage, sky, and pastel tones.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Server Structure**: RESTful API with route-based organization
- **Data Validation**: Zod schemas for type-safe validation
- **Development**: Hot module replacement with Vite integration
- **Error Handling**: Centralized error middleware with proper status codes

### Data Storage Strategy
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Development Storage**: In-memory storage implementation for rapid prototyping
- **Schema**: Structured tables for users, mood entries, journal entries, balance tracking, tasks, and wellness metrics

## Key Components

### Core Features
1. **Mood Tracking**: Emoji-based mood selection with energy level tracking
2. **Journal**: Free-form writing with optional prompts and word count
3. **Meditation**: Timer-based sessions with different focus areas
4. **Life Balance**: Multi-dimensional tracking (academic, social, self-care, physical)
5. **Planner**: Task management with Pomodoro timer and wellness tracking

### UI Components
- Custom-themed shadcn/ui components
- Responsive design with mobile-first approach
- Navigation with active state indicators
- Toast notifications for user feedback
- Consistent color scheme using CSS custom properties

### API Endpoints
- `GET/POST /api/mood-entries` - Mood tracking data
- `GET/POST /api/journal-entries` - Journal content management
- `GET/POST /api/balance-entries` - Life balance metrics
- `GET/POST /api/tasks` - Task management
- `GET/POST /api/wellness` - Daily wellness tracking

## Data Flow

### Client-Server Communication
1. **Query Pattern**: React Query manages all server state with automatic caching
2. **Optimistic Updates**: Immediate UI feedback with background synchronization
3. **Error Handling**: Consistent error boundaries with user-friendly messages
4. **Data Validation**: Zod schemas ensure data integrity at API boundaries

### State Management
- Server state handled by TanStack Query with query keys
- Local UI state managed with React hooks
- Form state managed with React Hook Form
- Toast notifications for user feedback

### Authentication Strategy
- Demo mode with hardcoded user ID (DEMO_USER_ID = 1)
- Architecture prepared for future authentication implementation
- User context ready for session management

## External Dependencies

### UI and Styling
- **Radix UI**: Accessible component primitives
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library
- **Class Variance Authority**: Component variant management

### Data and Validation
- **Drizzle ORM**: Type-safe database operations
- **Zod**: Runtime type validation
- **date-fns**: Date manipulation utilities

### Development Tools
- **Vite**: Build tool and dev server
- **TypeScript**: Type safety
- **ESBuild**: Fast JavaScript bundling
- **Replit Integration**: Development environment optimization

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds optimized React bundle to `dist/public`
2. **Backend**: ESBuild compiles TypeScript server to `dist/index.js`
3. **Assets**: Static files served from build directory

### Environment Configuration
- **Development**: Vite dev server with HMR and Express API
- **Production**: Static file serving with Express backend
- **Database**: Environment-based configuration with Drizzle migrations

### Database Management
- **Migrations**: Drizzle Kit handles schema changes
- **Connection**: Neon serverless PostgreSQL for production
- **Development**: In-memory storage for rapid iteration

### Key Architectural Decisions

1. **Monorepo Structure**: Frontend, backend, and shared code in single repository for easier development
2. **Type Safety**: End-to-end TypeScript with shared schemas between client and server
3. **Component Architecture**: Reusable UI components with consistent theming
4. **Data Layer**: Abstracted storage interface allowing for different implementations
5. **Development Experience**: Hot reloading, error overlays, and Replit integration for optimal DX

The application prioritizes user experience with smooth animations, immediate feedback, and an intuitive interface designed specifically for teenage users dealing with academic and personal stress.