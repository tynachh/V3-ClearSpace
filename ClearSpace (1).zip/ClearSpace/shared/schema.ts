import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mood: text("mood").notNull(),
  energy: integer("energy").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title"),
  content: text("content").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const balanceEntries = pgTable("balance_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  academic: integer("academic").notNull(),
  social: integer("social").notNull(),
  selfCare: integer("self_care").notNull(),
  physical: integer("physical").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  completed: boolean("completed").notNull().default(false),
  priority: text("priority").notNull().default("medium"),
  date: timestamp("date").notNull().defaultNow(),
});

export const wellness = pgTable("wellness", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  water: integer("water").notNull().default(0),
  waterGoal: integer("water_goal").notNull().default(8),
  exercise: integer("exercise").notNull().default(0),
  exerciseGoal: integer("exercise_goal").notNull().default(45),
  sleep: integer("sleep").notNull().default(0),
  bedtime: text("bedtime"),
  wakeTime: text("wake_time"),
  date: text("date").notNull(),
});

export const thoughtBubbles = pgTable("thought_bubbles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  color: text("color").notNull().default("sage"),
  priority: text("priority").notNull().default("medium"),
  date: timestamp("date").notNull().defaultNow(),
});

export const scheduleEvents = pgTable("schedule_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  time: text("time").notNull(),
  date: text("date").notNull(),
  color: text("color").notNull().default("sage"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  userId: true,
  date: true,
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  userId: true,
  date: true,
});

export const insertBalanceEntrySchema = createInsertSchema(balanceEntries).omit({
  id: true,
  userId: true,
  date: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  userId: true,
  date: true,
});

export const insertWellnessSchema = createInsertSchema(wellness).omit({
  id: true,
  userId: true,
});

export const insertThoughtBubbleSchema = createInsertSchema(thoughtBubbles).omit({
  id: true,
  userId: true,
  date: true,
});

export const insertScheduleEventSchema = createInsertSchema(scheduleEvents).omit({
  id: true,
  userId: true,
});

export const favoriteQuotes = pgTable("favorite_quotes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  quote: text("quote").notNull(),
  source: text("source"),
  dateAdded: date("date_added").default(sql`CURRENT_DATE`),
});

export const insertFavoriteQuoteSchema = createInsertSchema(favoriteQuotes, {
  quote: z.string().min(1),
  source: z.string().optional(),
}).omit({
  id: true,
  userId: true,
  dateAdded: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type FavoriteQuote = typeof favoriteQuotes.$inferSelect;
export type InsertFavoriteQuote = z.infer<typeof insertFavoriteQuoteSchema>;
export type User = typeof users.$inferSelect;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type BalanceEntry = typeof balanceEntries.$inferSelect;
export type InsertBalanceEntry = z.infer<typeof insertBalanceEntrySchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Wellness = typeof wellness.$inferSelect;
export type InsertWellness = z.infer<typeof insertWellnessSchema>;
export type ThoughtBubble = typeof thoughtBubbles.$inferSelect;
export type InsertThoughtBubble = z.infer<typeof insertThoughtBubbleSchema>;
export type ScheduleEvent = typeof scheduleEvents.$inferSelect;
export type InsertScheduleEvent = z.infer<typeof insertScheduleEventSchema>;
